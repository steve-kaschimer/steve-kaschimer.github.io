namespace Northstar.Architecture.Tests;

public sealed class ModuleBoundaryTests
{
    [Fact]
    public void Inventory_implementation_types_are_not_public()
    {
        var assembly =
            typeof(Northstar.Modules.Inventory.IInventoryModule)
                .Assembly;

        var leaked =
            assembly.GetExportedTypes()
                .Where(x =>
                    x.Name.Contains("DbContext") ||
                    x.Name == "InventoryReservation")
                .ToArray();

        Assert.Empty(leaked);
    }

    [Fact]
    public void Fulfillment_exposes_contract_not_implementation()
    {
        var implementation =
            typeof(Northstar.Modules.Fulfillment.IFulfillmentModule)
                .Assembly
                .GetTypes()
                .Single(x => x.Name == "FulfillmentModule");

        Assert.False(implementation.IsPublic);
    }
}
