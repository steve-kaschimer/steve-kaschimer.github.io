# Northstar v25 — Modular Monolith

Northstar now collapses Ordering, Inventory, and Fulfillment back into one deployable application while preserving explicit module boundaries.

Payment remains external.

```text
Northstar.Host
   |
   +-- Ordering
   +-- Inventory
   +-- Fulfillment
   |
External Payment
```

## Why This Is Better for This Stage

The previous distributed version required:

```text
RabbitMQ
Outbox
Inbox
Saga coordination
retry
dead-letter handling
multiple process lifecycles
```

for boundaries that did not necessarily need independent deployment.

Inside the modular monolith:

```text
Ordering -> Inventory
```

can be an in-process module contract.

A business operation that truly requires atomic consistency can use one local transaction.

We keep the module boundary even though we remove the network boundary.

## Run

```bash
dotnet restore
dotnet build
dotnet test
dotnet run --project src/Northstar.Host
```

## Structure

```text
src/
  Northstar.Host/
  Northstar.Modules.Ordering/
  Northstar.Modules.Inventory/
  Northstar.Modules.Fulfillment/
  Northstar.Modules.Payments.Contracts/
```

Each module exposes a narrow public contract.

Implementation details remain internal.

## The Rule

> Deployment boundaries are optional. Ownership boundaries are not.

## Break It

Try to reference `InventoryDbContext` from Ordering.

The project layout and internal visibility are designed to make that difficult.

The lab also includes architecture tests that verify forbidden project dependencies.

## What Remains Distributed

Payment remains behind a port because it still represents an external capability.

That keeps Timeout, Retry, Circuit Breaker, and idempotency relevant at the boundary where they belong.

## Lesson

We removed infrastructure without removing architecture.

That is the point.
