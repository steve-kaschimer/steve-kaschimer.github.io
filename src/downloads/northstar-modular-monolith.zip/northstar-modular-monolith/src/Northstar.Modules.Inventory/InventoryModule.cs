using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Northstar.Modules.Inventory;

public static class InventoryModuleRegistration
{
    public static IServiceCollection AddInventoryModule(
        this IServiceCollection services,
        string connectionString)
    {
        services.AddDbContext<InventoryDbContext>(
            options =>
                options.UseSqlite(connectionString));

        services.AddScoped<IInventoryModule, InventoryModule>();

        return services;
    }
}

internal sealed class InventoryDbContext(
    DbContextOptions<InventoryDbContext> options)
    : DbContext(options)
{
    public DbSet<InventoryReservation> Reservations =>
        Set<InventoryReservation>();
}

internal sealed class InventoryReservation
{
    private InventoryReservation() { }

    public InventoryReservation(
        Guid id,
        Guid orderId)
    {
        Id = id;
        OrderId = orderId;
        Status = "Reserved";
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public string Status { get; private set; } = "";

    public void Release()
        => Status = "Released";
}

internal sealed class InventoryModule(
    InventoryDbContext db)
    : IInventoryModule
{
    public async Task<InventoryReservationResult>
        ReserveAsync(
            Guid orderId,
            CancellationToken cancellationToken)
    {
        var reservation =
            new InventoryReservation(
                Guid.NewGuid(),
                orderId);

        db.Reservations.Add(reservation);
        await db.SaveChangesAsync(cancellationToken);

        return new(reservation.Id);
    }

    public async Task ReleaseAsync(
        Guid reservationId,
        CancellationToken cancellationToken)
    {
        var reservation =
            await db.Reservations.SingleAsync(
                x => x.Id == reservationId,
                cancellationToken);

        reservation.Release();

        await db.SaveChangesAsync(cancellationToken);
    }
}
