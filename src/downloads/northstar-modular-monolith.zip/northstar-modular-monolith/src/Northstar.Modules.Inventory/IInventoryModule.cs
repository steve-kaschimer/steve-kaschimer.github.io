namespace Northstar.Modules.Inventory;

public interface IInventoryModule
{
    Task<InventoryReservationResult> ReserveAsync(
        Guid orderId,
        CancellationToken cancellationToken);

    Task ReleaseAsync(
        Guid reservationId,
        CancellationToken cancellationToken);
}

public sealed record InventoryReservationResult(
    Guid ReservationId);
