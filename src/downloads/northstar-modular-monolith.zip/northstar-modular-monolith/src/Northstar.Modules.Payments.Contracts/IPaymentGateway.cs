namespace Northstar.Modules.Payments.Contracts;

public interface IPaymentGateway
{
    Task<PaymentDecision> AuthorizeAsync(
        Guid orderId,
        decimal amount,
        CancellationToken cancellationToken);
}

public sealed record PaymentDecision(
    bool Approved,
    Guid PaymentId,
    string? DeclineReason);
