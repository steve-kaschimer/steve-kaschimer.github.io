using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Northstar.Modules.Fulfillment;
using Northstar.Modules.Inventory;
using Northstar.Modules.Payments.Contracts;

namespace Northstar.Modules.Ordering;

public static class OrderingModuleRegistration
{
    public static IServiceCollection AddOrderingModule(
        this IServiceCollection services,
        string connectionString)
    {
        services.AddDbContext<OrderingDbContext>(
            options =>
                options.UseSqlite(connectionString));

        services.AddScoped<CheckoutUseCase>();

        return services;
    }
}

internal sealed class OrderingDbContext(
    DbContextOptions<OrderingDbContext> options)
    : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();
}

internal sealed class Order
{
    private Order() { }

    public Order(
        Guid id,
        decimal total)
    {
        Id = id;
        Total = total;
        Status = "Pending";
    }

    public Guid Id { get; private set; }
    public decimal Total { get; private set; }
    public string Status { get; private set; } = "";

    public void Complete()
        => Status = "Completed";

    public void Cancel()
        => Status = "Cancelled";
}

public sealed class CheckoutUseCase(
    OrderingDbContext db,
    IInventoryModule inventory,
    IPaymentGateway payments,
    IFulfillmentModule fulfillment)
{
    public async Task<CheckoutResult> ExecuteAsync(
        decimal amount,
        CancellationToken cancellationToken)
    {
        var order =
            new Order(
                Guid.NewGuid(),
                amount);

        db.Orders.Add(order);
        await db.SaveChangesAsync(cancellationToken);

        var reservation =
            await inventory.ReserveAsync(
                order.Id,
                cancellationToken);

        var payment =
            await payments.AuthorizeAsync(
                order.Id,
                order.Total,
                cancellationToken);

        if (!payment.Approved)
        {
            await inventory.ReleaseAsync(
                reservation.ReservationId,
                cancellationToken);

            order.Cancel();
            await db.SaveChangesAsync(cancellationToken);

            return new(
                order.Id,
                "Cancelled",
                payment.PaymentId);
        }

        await fulfillment.ScheduleAsync(
            order.Id,
            cancellationToken);

        order.Complete();
        await db.SaveChangesAsync(cancellationToken);

        return new(
            order.Id,
            "Completed",
            payment.PaymentId);
    }
}

public sealed record CheckoutResult(
    Guid OrderId,
    string Status,
    Guid PaymentId);
