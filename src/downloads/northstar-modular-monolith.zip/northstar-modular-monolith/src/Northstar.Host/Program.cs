using Northstar.Modules.Fulfillment;
using Northstar.Modules.Inventory;
using Northstar.Modules.Ordering;
using Northstar.Modules.Payments.Contracts;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddInventoryModule(
    "Data Source=inventory-module.db");

builder.Services.AddFulfillmentModule();

builder.Services.AddOrderingModule(
    "Data Source=ordering-module.db");

builder.Services.AddScoped<
    IPaymentGateway,
    FakePaymentGateway>();

var app = builder.Build();

app.MapPost(
    "/checkout",
    async (
        CheckoutRequest request,
        CheckoutUseCase checkout,
        CancellationToken cancellationToken) =>
        Results.Ok(
            await checkout.ExecuteAsync(
                request.Amount,
                cancellationToken)));

app.Run();

public sealed record CheckoutRequest(decimal Amount);

internal sealed class FakePaymentGateway
    : IPaymentGateway
{
    public Task<PaymentDecision> AuthorizeAsync(
        Guid orderId,
        decimal amount,
        CancellationToken cancellationToken)
        => Task.FromResult(
            new PaymentDecision(
                Approved: true,
                PaymentId: Guid.NewGuid(),
                DeclineReason: null));
}
