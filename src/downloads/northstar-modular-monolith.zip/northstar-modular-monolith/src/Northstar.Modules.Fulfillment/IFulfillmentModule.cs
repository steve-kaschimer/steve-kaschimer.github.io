namespace Northstar.Modules.Fulfillment;

public interface IFulfillmentModule
{
    Task ScheduleAsync(
        Guid orderId,
        CancellationToken cancellationToken);
}

internal sealed class FulfillmentModule
    : IFulfillmentModule
{
    public Task ScheduleAsync(
        Guid orderId,
        CancellationToken cancellationToken)
        => Task.CompletedTask;
}

public static class FulfillmentModuleRegistration
{
    public static Microsoft.Extensions.DependencyInjection.IServiceCollection
        AddFulfillmentModule(
            this Microsoft.Extensions.DependencyInjection.IServiceCollection services)
    {
        services.AddScoped<
            IFulfillmentModule,
            FulfillmentModule>();

        return services;
    }
}
