# Northstar Commerce — Baseline Application

This is the evolving Northstar Commerce application from Labs 1-13 of the
Northstar Architecture Lab, the companion codebase for volume 3 of
"Modern Application Architecture Patterns in .NET."

Read the numbered lab articles on the blog for the full narrative - each
one describes a specific pressure this codebase hit and the pattern that
resolved it: Domain Model, CQRS, Domain Events, Transactional Outbox,
Inbox / Idempotent Consumer, and Saga.

This archive contains the code as it stands after all thirteen stages;
it is not a series of separate per-stage snapshots. Read the article
alongside the relevant feature code to see what changed at each step.

## Run

```bash
dotnet restore
dotnet build
dotnet test
dotnet run --project src/Northstar.Api
```

## Structure

```text
src/Northstar.Api/            the application
tests/Northstar.Api.Tests/    tests, including several "break it" scenarios
                               described in the articles
```

## What to Try

Follow the "Break It" and "Reproduce It" experiments described in each
lab article - most of this application's important behavior only becomes
visible when something fails.
