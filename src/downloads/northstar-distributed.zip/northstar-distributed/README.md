# Northstar v24 — Modular Monolith Pressure

This stage is intentionally analytical.

Before changing the topology, inspect the forces that justified each service boundary.

The question is not:

```text
Can these be microservices?
```

It is:

```text
Which boundaries need independent deployment badly enough
to pay for distributed failure?
```

See:

```text
docs/23-modular-monolith-pressure.md
```
