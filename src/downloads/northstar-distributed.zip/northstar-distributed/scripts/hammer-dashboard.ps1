param(
    [int]$Count = 200,
    [string]$BaseUrl = "http://localhost:5100"
)

1..$Count | ForEach-Object -Parallel {
    try {
        Invoke-RestMethod `
            -Method Get `
            -Uri "$using:BaseUrl/operations/dashboard" | Out-Null

        "200"
    }
    catch {
        $_.Exception.Response.StatusCode.value__
    }
} -ThrottleLimit 30
