param(
    [int]$Count = 100,
    [string]$BaseUrl = "http://localhost:5100"
)

1..$Count | ForEach-Object -Parallel {
    $body = @{
        orderId = [guid]::NewGuid()
        amount = 125.00
    } | ConvertTo-Json

    try {
        Invoke-RestMethod `
            -Method Post `
            -Uri "$using:BaseUrl/checkouts" `
            -ContentType "application/json" `
            -Body $body
    }
    catch {
        $_.Exception.Response.StatusCode.value__
    }
} -ThrottleLimit 25
