namespace Northstar.Contracts;

public interface IMessage
{
    Guid MessageId { get; }
    Guid SagaId { get; }
}

public sealed record ReserveInventory(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId)
    : IMessage;

public sealed record InventoryReserved(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId,
    Guid ReservationId)
    : IMessage;

public sealed record AuthorizePayment(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId,
    decimal Amount)
    : IMessage;

public sealed record PaymentAuthorized(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId,
    Guid PaymentId)
    : IMessage;

public sealed record PaymentDeclined(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId,
    Guid PaymentId,
    string Reason)
    : IMessage;

public sealed record ReleaseInventory(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId,
    Guid ReservationId)
    : IMessage;

public sealed record InventoryReleased(
    Guid MessageId,
    Guid SagaId,
    Guid OrderId,
    Guid ReservationId)
    : IMessage;
