using Microsoft.EntityFrameworkCore;
using Northstar.Inventory.Worker;
using Northstar.Messaging;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddDbContext<InventoryDbContext>(
    options =>
        options.UseSqlite(
            "Data Source=inventory.db"));

builder.Services.AddSingleton<RabbitMqConnection>();
builder.Services.AddSingleton<RabbitMqBus>();

builder.Services.AddHostedService<ReserveInventoryConsumer>();
builder.Services.AddHostedService<ReleaseInventoryConsumer>();
builder.Services.AddHostedService<OutboxDispatcher>();

builder.Services.AddOpenTelemetry()
    .WithTracing(tracing =>
        tracing
            .AddSource("Northstar.Messaging")
            .AddConsoleExporter())
    .WithMetrics(metrics =>
        metrics
            .AddMeter("Northstar.Messaging")
            .AddConsoleExporter());

var host = builder.Build();

await using (var scope = host.Services.CreateAsyncScope())
{
    var db =
        scope.ServiceProvider
            .GetRequiredService<InventoryDbContext>();

    await db.Database.EnsureCreatedAsync();
}

await host.RunAsync();
