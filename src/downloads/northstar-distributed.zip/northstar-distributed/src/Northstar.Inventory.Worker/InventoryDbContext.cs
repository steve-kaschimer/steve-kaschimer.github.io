using Microsoft.EntityFrameworkCore;

namespace Northstar.Inventory.Worker;

public sealed class InventoryDbContext(
    DbContextOptions<InventoryDbContext> options)
    : DbContext(options)
{
    public DbSet<InventoryReservation> Reservations =>
        Set<InventoryReservation>();

    public DbSet<InboxMessage> InboxMessages =>
        Set<InboxMessage>();

    public DbSet<OutboxMessage> OutboxMessages =>
        Set<OutboxMessage>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<InventoryReservation>()
            .HasKey(x => x.Id);

        modelBuilder.Entity<InboxMessage>()
            .HasKey(x => x.MessageId);

        modelBuilder.Entity<OutboxMessage>()
            .HasKey(x => x.Id);
    }
}

public sealed class InventoryReservation
{
    private InventoryReservation() { }

    public InventoryReservation(
        Guid id,
        Guid orderId)
    {
        Id = id;
        OrderId = orderId;
        Status = "Reserved";
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public string Status { get; private set; } = "";

    public void Release() => Status = "Released";
}

public sealed class InboxMessage
{
    private InboxMessage() { }

    public Guid MessageId { get; private set; }

    public static InboxMessage Create(Guid id)
        => new() { MessageId = id };
}


public sealed class OutboxMessage
{
    private OutboxMessage() { }

    public Guid Id { get; private set; }
    public string RoutingKey { get; private set; } = "";
    public string Type { get; private set; } = "";
    public string Payload { get; private set; } = "";
    public DateTimeOffset CreatedAt { get; private set; }
    public DateTimeOffset? PublishedAt { get; private set; }

    public static OutboxMessage Create(
        Guid id,
        string routingKey,
        string type,
        string payload,
        DateTimeOffset createdAt)
        => new()
        {
            Id = id,
            RoutingKey = routingKey,
            Type = type,
            Payload = payload,
            CreatedAt = createdAt
        };

    public void MarkPublished(DateTimeOffset now)
        => PublishedAt = now;
}
