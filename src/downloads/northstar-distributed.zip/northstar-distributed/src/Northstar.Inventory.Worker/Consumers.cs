using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;

namespace Northstar.Inventory.Worker;

public sealed class ReserveInventoryConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes)
    : RabbitMqConsumer<ReserveInventory>(
        connection,
        "inventory.reserve",
        "inventory.reserve")
{
    protected override async Task HandleAsync(
        ReserveInventory message,
        CancellationToken cancellationToken)
    {
        await using var scope = scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<InventoryDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x => x.MessageId == message.MessageId,
            cancellationToken))
        {
            return;
        }

        var reservation =
            new InventoryReservation(
                Guid.NewGuid(),
                message.OrderId);

        db.Reservations.Add(reservation);
        db.InboxMessages.Add(
            InboxMessage.Create(message.MessageId));

        var reply =
            new InventoryReserved(
                Guid.NewGuid(),
                message.SagaId,
                message.OrderId,
                reservation.Id);

        OutboxWriter.Add(
            db,
            "inventory.reserved",
            reply.MessageId,
            reply,
            DateTimeOffset.UtcNow);

        await db.SaveChangesAsync(cancellationToken);
    }
}

public sealed class ReleaseInventoryConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes)
    : RabbitMqConsumer<ReleaseInventory>(
        connection,
        "inventory.release",
        "inventory.release")
{
    protected override async Task HandleAsync(
        ReleaseInventory message,
        CancellationToken cancellationToken)
    {
        await using var scope = scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<InventoryDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x => x.MessageId == message.MessageId,
            cancellationToken))
        {
            return;
        }

        var reservation =
            await db.Reservations.SingleAsync(
                x => x.Id == message.ReservationId,
                cancellationToken);

        reservation.Release();

        db.InboxMessages.Add(
            InboxMessage.Create(message.MessageId));

        var reply =
            new InventoryReleased(
                Guid.NewGuid(),
                message.SagaId,
                message.OrderId,
                reservation.Id);

        OutboxWriter.Add(
            db,
            "inventory.released",
            reply.MessageId,
            reply,
            DateTimeOffset.UtcNow);

        await db.SaveChangesAsync(cancellationToken);
    }
}
