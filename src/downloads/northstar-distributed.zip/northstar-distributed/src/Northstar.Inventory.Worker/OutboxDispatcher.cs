using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;

namespace Northstar.Inventory.Worker;

public sealed class OutboxDispatcher(
    IServiceScopeFactory scopes,
    RabbitMqBus bus)
    : BackgroundService
{
    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await using var scope = scopes.CreateAsyncScope();

            var db =
                scope.ServiceProvider
                    .GetRequiredService<InventoryDbContext>();

            var rows = await db.OutboxMessages
                .Where(x => x.PublishedAt == null)
                .OrderBy(x => x.CreatedAt)
                .Take(50)
                .ToListAsync(stoppingToken);

            foreach (var row in rows)
            {
                switch (row.Type)
                {
                    case nameof(InventoryReserved):
                        await bus.PublishAsync(
                            row.RoutingKey,
                            JsonSerializer.Deserialize<InventoryReserved>(
                                row.Payload)!,
                            stoppingToken);
                        break;

                    case nameof(InventoryReleased):
                        await bus.PublishAsync(
                            row.RoutingKey,
                            JsonSerializer.Deserialize<InventoryReleased>(
                                row.Payload)!,
                            stoppingToken);
                        break;

                    default:
                        throw new InvalidOperationException(
                            $"Unknown Inventory Outbox type {row.Type}");
                }

                row.MarkPublished(DateTimeOffset.UtcNow);
            }

            await db.SaveChangesAsync(stoppingToken);

            await Task.Delay(
                TimeSpan.FromSeconds(1),
                stoppingToken);
        }
    }
}
