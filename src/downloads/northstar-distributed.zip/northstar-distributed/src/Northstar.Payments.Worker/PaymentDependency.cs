using Microsoft.Extensions.Resilience;
using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;
using Polly.Timeout;

namespace Northstar.Payments.Worker;

public sealed class PaymentDependency(
    ResiliencePipelineProvider<string> pipelines)
{
    public Task ExecuteAsync(
        CancellationToken cancellationToken)
        => pipelines
            .GetPipeline("payment-dependency")
            .ExecuteAsync(
                static async token =>
                {
                    var delayText =
                        Environment.GetEnvironmentVariable(
                            "NORTHSTAR_PAYMENT_DELAY_MS");

                    if (int.TryParse(delayText, out var delayMs) &&
                        delayMs > 0)
                    {
                        await Task.Delay(
                            delayMs,
                            token);
                    }

                    var fail =
                        string.Equals(
                            Environment.GetEnvironmentVariable(
                                "NORTHSTAR_PAYMENT_FAIL"),
                            "true",
                            StringComparison.OrdinalIgnoreCase);

                    if (fail)
                        throw new HttpRequestException(
                            "Simulated payment dependency outage.");
                },
                cancellationToken)
            .AsTask();
}
