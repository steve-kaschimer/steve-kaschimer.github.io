using Microsoft.EntityFrameworkCore;
using Northstar.Messaging;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;
using Northstar.Payments.Worker;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddDbContext<PaymentsDbContext>(
    options =>
        options.UseSqlite(
            "Data Source=payments.db"));

builder.Services.AddSingleton<RabbitMqConnection>();
builder.Services.AddSingleton<RabbitMqBus>();

builder.Services.AddResiliencePipeline(
    "payment-dependency",
    pipeline =>
    {
        pipeline.AddConcurrencyLimiter(
            new Polly.RateLimiting.ConcurrencyLimiterOptions
            {
                PermitLimit = 8,
                QueueLimit = 16
            });

        pipeline.AddTimeout(
            TimeSpan.FromSeconds(3));

        pipeline.AddRetry(
            new RetryStrategyOptions
            {
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromMilliseconds(250),
                BackoffType = DelayBackoffType.Exponential,
                UseJitter = true
            });

        pipeline.AddCircuitBreaker(
            new CircuitBreakerStrategyOptions
            {
                FailureRatio = 0.5,
                SamplingDuration = TimeSpan.FromSeconds(10),
                MinimumThroughput = 4,
                BreakDuration = TimeSpan.FromSeconds(15)
            });
    });

builder.Services.AddSingleton<PaymentDependency>();

builder.Services.AddHostedService<AuthorizePaymentConsumer>();
builder.Services.AddHostedService<OutboxDispatcher>();

builder.Services.AddOpenTelemetry()
    .WithTracing(tracing =>
        tracing
            .AddSource("Northstar.Messaging")
            .AddConsoleExporter())
    .WithMetrics(metrics =>
        metrics
            .AddMeter("Northstar.Messaging")
            .AddConsoleExporter());

var host = builder.Build();

await using (var scope = host.Services.CreateAsyncScope())
{
    var db =
        scope.ServiceProvider
            .GetRequiredService<PaymentsDbContext>();

    await db.Database.EnsureCreatedAsync();
}

await host.RunAsync();
