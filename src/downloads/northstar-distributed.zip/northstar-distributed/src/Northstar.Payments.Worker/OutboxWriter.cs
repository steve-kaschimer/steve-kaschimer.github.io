using System.Text.Json;

namespace Northstar.Payments.Worker;

public static class OutboxWriter
{
    public static void Add<T>(
        PaymentsDbContext db,
        string routingKey,
        Guid messageId,
        T message,
        DateTimeOffset now)
    {
        db.OutboxMessages.Add(
            OutboxMessage.Create(
                messageId,
                routingKey,
                typeof(T).Name,
                JsonSerializer.Serialize(message),
                now));
    }
}
