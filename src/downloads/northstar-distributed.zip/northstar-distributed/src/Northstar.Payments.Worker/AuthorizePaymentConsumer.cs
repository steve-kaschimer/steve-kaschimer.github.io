using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;

namespace Northstar.Payments.Worker;

public sealed class AuthorizePaymentConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes,
    PaymentDependency dependency)
    : RabbitMqConsumer<AuthorizePayment>(
        connection,
        "payment.authorize",
        "payment.authorize")
{
    protected override async Task HandleAsync(
        AuthorizePayment message,
        CancellationToken cancellationToken)
    {
        await using var scope = scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<PaymentsDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x => x.MessageId == message.MessageId,
            cancellationToken))
        {
            return;
        }

        await dependency.ExecuteAsync(
            cancellationToken);

        var decline =
            string.Equals(
                Environment.GetEnvironmentVariable(
                    "NORTHSTAR_DECLINE_PAYMENTS"),
                "true",
                StringComparison.OrdinalIgnoreCase);

        var payment =
            new PaymentAttempt(
                Guid.NewGuid(),
                message.OrderId,
                message.Amount,
                decline ? "Declined" : "Authorized");

        db.Payments.Add(payment);
        db.InboxMessages.Add(
            InboxMessage.Create(message.MessageId));

        if (decline)
        {
            var reply =
                new PaymentDeclined(
                    Guid.NewGuid(),
                    message.SagaId,
                    message.OrderId,
                    payment.Id,
                    "Lab-configured decline");

            OutboxWriter.Add(
                db,
                "payment.declined",
                reply.MessageId,
                reply,
                DateTimeOffset.UtcNow);
        }
        else
        {
            var reply =
                new PaymentAuthorized(
                    Guid.NewGuid(),
                    message.SagaId,
                    message.OrderId,
                    payment.Id);

            OutboxWriter.Add(
                db,
                "payment.authorized",
                reply.MessageId,
                reply,
                DateTimeOffset.UtcNow);
        }

        await db.SaveChangesAsync(cancellationToken);
    }
}
