using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;

namespace Northstar.Payments.Worker;

public sealed class OutboxDispatcher(
    IServiceScopeFactory scopes,
    RabbitMqBus bus)
    : BackgroundService
{
    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await using var scope = scopes.CreateAsyncScope();

            var db =
                scope.ServiceProvider
                    .GetRequiredService<PaymentsDbContext>();

            var rows = await db.OutboxMessages
                .Where(x => x.PublishedAt == null)
                .OrderBy(x => x.CreatedAt)
                .Take(50)
                .ToListAsync(stoppingToken);

            foreach (var row in rows)
            {
                switch (row.Type)
                {
                    case nameof(PaymentAuthorized):
                        await bus.PublishAsync(
                            row.RoutingKey,
                            JsonSerializer.Deserialize<PaymentAuthorized>(
                                row.Payload)!,
                            stoppingToken);
                        break;

                    case nameof(PaymentDeclined):
                        await bus.PublishAsync(
                            row.RoutingKey,
                            JsonSerializer.Deserialize<PaymentDeclined>(
                                row.Payload)!,
                            stoppingToken);
                        break;

                    default:
                        throw new InvalidOperationException(
                            $"Unknown Payments Outbox type {row.Type}");
                }

                row.MarkPublished(DateTimeOffset.UtcNow);
            }

            await db.SaveChangesAsync(stoppingToken);

            await Task.Delay(
                TimeSpan.FromSeconds(1),
                stoppingToken);
        }
    }
}
