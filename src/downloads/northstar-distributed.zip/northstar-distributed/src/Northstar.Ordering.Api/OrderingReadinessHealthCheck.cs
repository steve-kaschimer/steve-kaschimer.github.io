using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Northstar.Ordering.Api;

public sealed class OrderingReadinessHealthCheck
    : IHealthCheck
{
    public Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        // Teaching example:
        // readiness reflects whether this instance should receive traffic,
        // not whether every optional dependency in the universe is healthy.
        return Task.FromResult(
            HealthCheckResult.Healthy(
                "Ordering is ready to accept traffic."));
    }
}
