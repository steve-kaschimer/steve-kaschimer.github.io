using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;

namespace Northstar.Ordering.Api;

public sealed class InventoryReservedConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes)
    : RabbitMqConsumer<InventoryReserved>(
        connection,
        "ordering.inventory-reserved",
        "inventory.reserved")
{
    protected override async Task HandleAsync(
        InventoryReserved message,
        CancellationToken cancellationToken)
    {
        await using var scope =
            scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<OrderingDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x =>
                x.MessageId == message.MessageId &&
                x.Handler == nameof(InventoryReservedConsumer),
            cancellationToken))
        {
            return;
        }

        var saga =
            await db.CheckoutSagas.SingleAsync(
                x => x.Id == message.SagaId,
                cancellationToken);

        saga.InventoryReserved(
            message.ReservationId);

        var next =
            new AuthorizePayment(
                Guid.NewGuid(),
                saga.Id,
                saga.OrderId,
                saga.Amount);

        db.InboxMessages.Add(
            InboxMessage.Create(
                message.MessageId,
                nameof(InventoryReservedConsumer),
                DateTimeOffset.UtcNow));

        OutboxWriter.Add(
            db,
            "payment.authorize",
            next.MessageId,
            next,
            DateTimeOffset.UtcNow);

        await db.SaveChangesAsync(
            cancellationToken);
    }
}

public sealed class PaymentAuthorizedConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes)
    : RabbitMqConsumer<PaymentAuthorized>(
        connection,
        "ordering.payment-authorized",
        "payment.authorized")
{
    protected override async Task HandleAsync(
        PaymentAuthorized message,
        CancellationToken cancellationToken)
    {
        await using var scope =
            scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<OrderingDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x =>
                x.MessageId == message.MessageId &&
                x.Handler == nameof(PaymentAuthorizedConsumer),
            cancellationToken))
        {
            return;
        }

        var saga =
            await db.CheckoutSagas.SingleAsync(
                x => x.Id == message.SagaId,
                cancellationToken);

        saga.PaymentAuthorized(
            message.PaymentId,
            DateTimeOffset.UtcNow);

        db.InboxMessages.Add(
            InboxMessage.Create(
                message.MessageId,
                nameof(PaymentAuthorizedConsumer),
                DateTimeOffset.UtcNow));

        await db.SaveChangesAsync(
            cancellationToken);
    }
}

public sealed class PaymentDeclinedConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes)
    : RabbitMqConsumer<PaymentDeclined>(
        connection,
        "ordering.payment-declined",
        "payment.declined")
{
    protected override async Task HandleAsync(
        PaymentDeclined message,
        CancellationToken cancellationToken)
    {
        await using var scope =
            scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<OrderingDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x =>
                x.MessageId == message.MessageId &&
                x.Handler == nameof(PaymentDeclinedConsumer),
            cancellationToken))
        {
            return;
        }

        var saga =
            await db.CheckoutSagas.SingleAsync(
                x => x.Id == message.SagaId,
                cancellationToken);

        saga.PaymentDeclined(
            message.PaymentId);

        var release =
            new ReleaseInventory(
                Guid.NewGuid(),
                saga.Id,
                saga.OrderId,
                saga.ReservationId
                    ?? throw new InvalidOperationException(
                        "Reservation is missing."));

        db.InboxMessages.Add(
            InboxMessage.Create(
                message.MessageId,
                nameof(PaymentDeclinedConsumer),
                DateTimeOffset.UtcNow));

        OutboxWriter.Add(
            db,
            "inventory.release",
            release.MessageId,
            release,
            DateTimeOffset.UtcNow);

        await db.SaveChangesAsync(
            cancellationToken);
    }
}

public sealed class InventoryReleasedConsumer(
    RabbitMqConnection connection,
    IServiceScopeFactory scopes)
    : RabbitMqConsumer<InventoryReleased>(
        connection,
        "ordering.inventory-released",
        "inventory.released")
{
    protected override async Task HandleAsync(
        InventoryReleased message,
        CancellationToken cancellationToken)
    {
        await using var scope =
            scopes.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<OrderingDbContext>();

        if (await db.InboxMessages.AnyAsync(
            x =>
                x.MessageId == message.MessageId &&
                x.Handler == nameof(InventoryReleasedConsumer),
            cancellationToken))
        {
            return;
        }

        var saga =
            await db.CheckoutSagas.SingleAsync(
                x => x.Id == message.SagaId,
                cancellationToken);

        saga.InventoryReleased(
            DateTimeOffset.UtcNow);

        db.InboxMessages.Add(
            InboxMessage.Create(
                message.MessageId,
                nameof(InventoryReleasedConsumer),
                DateTimeOffset.UtcNow));

        await db.SaveChangesAsync(
            cancellationToken);
    }
}
