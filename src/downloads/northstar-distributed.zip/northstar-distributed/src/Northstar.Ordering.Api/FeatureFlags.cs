namespace Northstar.Ordering.Api;

public sealed class FeatureFlags(
    IConfiguration configuration)
{
    public bool NewCheckoutFlowEnabled =>
        configuration.GetValue<bool>(
            "Features:NewCheckoutFlow");
}
