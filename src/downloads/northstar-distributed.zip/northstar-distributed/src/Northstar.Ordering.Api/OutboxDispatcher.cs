using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;

namespace Northstar.Ordering.Api;

public sealed class OutboxDispatcher(
    IServiceScopeFactory scopeFactory,
    RabbitMqBus bus)
    : BackgroundService
{
    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await using var scope =
                scopeFactory.CreateAsyncScope();

            var db =
                scope.ServiceProvider
                    .GetRequiredService<OrderingDbContext>();

            var rows = await db.OutboxMessages
                .Where(x => x.PublishedAt == null)
                .OrderBy(x => x.CreatedAt)
                .Take(50)
                .ToListAsync(stoppingToken);

            foreach (var row in rows)
            {
                object message = row.Type switch
                {
                    nameof(ReserveInventory) =>
                        JsonSerializer.Deserialize<ReserveInventory>(
                            row.Payload)!,

                    nameof(AuthorizePayment) =>
                        JsonSerializer.Deserialize<AuthorizePayment>(
                            row.Payload)!,

                    nameof(ReleaseInventory) =>
                        JsonSerializer.Deserialize<ReleaseInventory>(
                            row.Payload)!,

                    _ => throw new InvalidOperationException(
                        $"Unknown Outbox type {row.Type}")
                };

                switch (message)
                {
                    case ReserveInventory value:
                        await bus.PublishAsync(
                            row.RoutingKey,
                            value,
                            stoppingToken);
                        break;

                    case AuthorizePayment value:
                        await bus.PublishAsync(
                            row.RoutingKey,
                            value,
                            stoppingToken);
                        break;

                    case ReleaseInventory value:
                        await bus.PublishAsync(
                            row.RoutingKey,
                            value,
                            stoppingToken);
                        break;
                }

                row.MarkPublished(
                    DateTimeOffset.UtcNow);
            }

            await db.SaveChangesAsync(stoppingToken);

            await Task.Delay(
                TimeSpan.FromSeconds(1),
                stoppingToken);
        }
    }
}
