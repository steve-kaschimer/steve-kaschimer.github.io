using Microsoft.EntityFrameworkCore;

namespace Northstar.Ordering.Api;

public sealed class SagaDeadlineMonitor(
    IServiceScopeFactory scopes,
    ILogger<SagaDeadlineMonitor> logger)
    : BackgroundService
{
    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await using var scope = scopes.CreateAsyncScope();

            var db = scope.ServiceProvider
                .GetRequiredService<OrderingDbContext>();

            var now = DateTimeOffset.UtcNow;

            var expired = await db.CheckoutSagas
                .Where(x =>
                    x.CompletedAt == null &&
                    x.DeadlineAt <= now)
                .ToListAsync(stoppingToken);

            foreach (var saga in expired)
            {
                saga.MarkTimedOut(now);

                logger.LogWarning(
                    "Checkout Saga {SagaId} timed out in state {Status}",
                    saga.Id,
                    saga.Status);
            }

            await db.SaveChangesAsync(stoppingToken);

            await Task.Delay(
                TimeSpan.FromSeconds(2),
                stoppingToken);
        }
    }
}
