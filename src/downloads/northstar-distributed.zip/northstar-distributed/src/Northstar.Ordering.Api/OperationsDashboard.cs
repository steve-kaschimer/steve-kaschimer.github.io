using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Northstar.Ordering.Api;

public sealed record OperationsDashboard(
    int TotalSagas,
    int ActiveSagas,
    int TimedOutSagas,
    int CompensatedSagas,
    decimal AverageAmount,
    IReadOnlyList<SlowSagaItem> Slowest);

public sealed record SlowSagaItem(
    Guid SagaId,
    Guid OrderId,
    string Status,
    decimal Amount,
    DateTimeOffset StartedAt,
    DateTimeOffset DeadlineAt);

public sealed class OperationsDashboardQuery(
    OrderingDbContext db,
    IMemoryCache cache)
{
    private const string CacheKey =
        "operations-dashboard:v1";

    private static readonly SemaphoreSlim RefreshGate =
        new(1, 1);
    public async Task<OperationsDashboard> ExecuteAsync(
        CancellationToken cancellationToken)
    {
        if (cache.TryGetValue<OperationsDashboard>(
            CacheKey,
            out var cached) &&
            cached is not null)
        {
            return cached;
        }

        // Prevent a cache stampede when many callers miss at once.
        await RefreshGate.WaitAsync(cancellationToken);

        try
        {
            if (cache.TryGetValue<OperationsDashboard>(
                CacheKey,
                out cached) &&
                cached is not null)
            {
                return cached;
            }

        var total =
            await db.CheckoutSagas.CountAsync(
                cancellationToken);

        var active =
            await db.CheckoutSagas.CountAsync(
                x => x.CompletedAt == null,
                cancellationToken);

        var timedOut =
            await db.CheckoutSagas.CountAsync(
                x => x.Status == "TimedOut",
                cancellationToken);

        var compensated =
            await db.CheckoutSagas.CountAsync(
                x => x.Status == "Compensated",
                cancellationToken);

        var average =
            await db.CheckoutSagas
                .Select(x => x.Amount)
                .DefaultIfEmpty()
                .AverageAsync(cancellationToken);

        var slowest =
            await db.CheckoutSagas
                .AsNoTracking()
                .OrderByDescending(x =>
                    x.CompletedAt == null
                        ? DateTimeOffset.UtcNow - x.StartedAt
                        : x.CompletedAt.Value - x.StartedAt)
                .Take(20)
                .Select(x => new SlowSagaItem(
                    x.Id,
                    x.OrderId,
                    x.Status,
                    x.Amount,
                    x.StartedAt,
                    x.DeadlineAt))
                .ToListAsync(cancellationToken);

        var dashboard =
            new OperationsDashboard(
                total,
                active,
                timedOut,
                compensated,
                average,
                slowest);

        cache.Set(
            CacheKey,
            dashboard,
            new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow =
                    TimeSpan.FromSeconds(5),
                Size = 1
            });

        return dashboard;
        }
        finally
        {
            RefreshGate.Release();
        }
    }

    public void Invalidate()
        => cache.Remove(CacheKey);
}
