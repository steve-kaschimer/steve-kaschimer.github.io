namespace Northstar.Ordering.Api;

public sealed class CheckoutSaga
{
    private CheckoutSaga() { }

    public CheckoutSaga(
        Guid id,
        Guid orderId,
        decimal amount,
        DateTimeOffset startedAt)
    {
        Id = id;
        OrderId = orderId;
        Amount = amount;
        StartedAt = startedAt;
        DeadlineAt = startedAt.AddSeconds(30);
        Status = "Started";
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public decimal Amount { get; private set; }
    public string Status { get; private set; } = "";
    public Guid? ReservationId { get; private set; }
    public Guid? PaymentId { get; private set; }
    public DateTimeOffset StartedAt { get; private set; }
    public DateTimeOffset DeadlineAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }
    public long Version { get; private set; }

    public void InventoryReserved(Guid reservationId)
    {
        ReservationId = reservationId;
        Status = "InventoryReserved";
        Version++;
    }

    public void PaymentAuthorized(Guid paymentId, DateTimeOffset now)
    {
        PaymentId = paymentId;
        Status = "Completed";
        CompletedAt = now;
        Version++;
    }

    public void PaymentDeclined(Guid paymentId)
    {
        PaymentId = paymentId;
        Status = "Compensating";
        Version++;
    }

    public void InventoryReleased(DateTimeOffset now)
    {
        Status = "Compensated";
        CompletedAt = now;
        Version++;
    }

    public void MarkTimedOut(DateTimeOffset now)
    {
        if (CompletedAt is not null)
            return;

        Status = "TimedOut";
        CompletedAt = now;
        Version++;
    }
}
