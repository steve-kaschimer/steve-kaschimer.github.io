using Microsoft.EntityFrameworkCore;
using Northstar.Contracts;
using Northstar.Messaging;
using Northstar.Ordering.Api;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMemoryCache(options =>
{
    options.SizeLimit = 100;
});

builder.Services.AddDbContext<OrderingDbContext>(
    options =>
        options.UseSqlite(
            "Data Source=ordering.db"));

builder.Services.AddSingleton<RabbitMqConnection>();
builder.Services.AddSingleton<RabbitMqBus>();

builder.Services.AddHostedService<OutboxDispatcher>();
builder.Services.AddHostedService<InventoryReservedConsumer>();
builder.Services.AddHostedService<PaymentAuthorizedConsumer>();
builder.Services.AddHostedService<PaymentDeclinedConsumer>();
builder.Services.AddHostedService<InventoryReleasedConsumer>();
builder.Services.AddHostedService<SagaDeadlineMonitor>();
builder.Services.AddScoped<OperationsDashboardQuery>();
builder.Services.AddSingleton<FeatureFlags>();
builder.Services.AddHealthChecks()
    .AddCheck<OrderingReadinessHealthCheck>(
        "ordering-readiness",
        tags: ["ready"]);


builder.Services.AddRateLimiter(options =>
{
    options.AddPolicy(
        "checkout",
        context =>
            RateLimitPartition.GetTokenBucketLimiter(
                partitionKey:
                    context.Connection.RemoteIpAddress?.ToString()
                    ?? "unknown",
                factory: _ =>
                    new TokenBucketRateLimiterOptions
                    {
                        TokenLimit = 20,
                        TokensPerPeriod = 10,
                        ReplenishmentPeriod =
                            TimeSpan.FromSeconds(1),
                        AutoReplenishment = true,
                        QueueLimit = 0
                    }));

    options.RejectionStatusCode =
        StatusCodes.Status429TooManyRequests;
});

builder.Services.AddOpenTelemetry()
    .WithTracing(tracing =>
        tracing
            .AddAspNetCoreInstrumentation()
            .AddSource("Northstar.Messaging")
            .AddConsoleExporter())
    .WithMetrics(metrics =>
        metrics
            .AddMeter("Northstar.Messaging")
            .AddConsoleExporter());

var app = builder.Build();

app.UseRateLimiter();

app.MapHealthChecks(
    "/health/live",
    new HealthCheckOptions
    {
        Predicate = _ => false
    });

app.MapHealthChecks(
    "/health/ready",
    new HealthCheckOptions
    {
        Predicate = check =>
            check.Tags.Contains("ready")
    });

await using (var scope = app.Services.CreateAsyncScope())
{
    var db =
        scope.ServiceProvider
            .GetRequiredService<OrderingDbContext>();

    await db.Database.EnsureCreatedAsync();
}

app.MapPost(
    "/checkouts",
    async (
        StartCheckoutRequest request,
        OrderingDbContext db,
        CancellationToken cancellationToken) =>
    {
        var flags =
            app.Services.GetRequiredService<FeatureFlags>();

        var saga = new CheckoutSaga(
            Guid.NewGuid(),
            request.OrderId,
            request.Amount,
            DateTimeOffset.UtcNow);

        if (flags.NewCheckoutFlowEnabled)
        {
            // The new flow is intentionally behaviorally equivalent
            // in this stage. The flag demonstrates release control
            // before the implementation diverges.
        }

        db.CheckoutSagas.Add(saga);

        var command =
            new ReserveInventory(
                Guid.NewGuid(),
                saga.Id,
                saga.OrderId);

        OutboxWriter.Add(
            db,
            "inventory.reserve",
            command.MessageId,
            command,
            DateTimeOffset.UtcNow);

        await db.SaveChangesAsync(
            cancellationToken);

        return Results.Accepted(
            $"/checkouts/{saga.Id}",
            new
            {
                sagaId = saga.Id,
                status = saga.Status
            });
    })
    .RequireRateLimiting("checkout");

app.MapPost(
    "/operations/dashboard/invalidate",
    (OperationsDashboardQuery query) =>
    {
        query.Invalidate();
        return Results.NoContent();
    });

app.MapGet(
    "/operations/dashboard",
    async (
        OperationsDashboardQuery query,
        CancellationToken cancellationToken) =>
        Results.Ok(
            await query.ExecuteAsync(
                cancellationToken)));

app.MapPost(
    "/checkouts/{id:guid}/timeout",
    async (
        Guid id,
        MarkTimedOutRequest request,
        OrderingDbContext db,
        CancellationToken cancellationToken) =>
    {
        var saga = await db.CheckoutSagas
            .SingleOrDefaultAsync(
                x => x.Id == id,
                cancellationToken);

        if (saga is null)
            return Results.NotFound();

        if (saga.Version != request.ExpectedVersion)
        {
            return Results.Conflict(new
            {
                expected = request.ExpectedVersion,
                actual = saga.Version
            });
        }

        saga.MarkTimedOut(
            DateTimeOffset.UtcNow);

        try
        {
            await db.SaveChangesAsync(
                cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            return Results.Conflict(new
            {
                message =
                    "Saga changed while this update was being committed."
            });
        }

        return Results.Ok(new
        {
            saga.Id,
            saga.Status,
            saga.Version
        });
    });

app.MapGet(
    "/checkouts/{id:guid}",
    async (
        Guid id,
        OrderingDbContext db,
        CancellationToken cancellationToken) =>
    {
        var saga =
            await db.CheckoutSagas
                .AsNoTracking()
                .SingleOrDefaultAsync(
                    x => x.Id == id,
                    cancellationToken);

        return saga is null
            ? Results.NotFound()
            : Results.Ok(saga);
    });

app.Run();

public sealed record StartCheckoutRequest(
    Guid OrderId,
    decimal Amount);

public sealed record MarkTimedOutRequest(long ExpectedVersion);
