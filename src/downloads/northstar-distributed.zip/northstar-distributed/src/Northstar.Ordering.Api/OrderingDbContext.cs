using Microsoft.EntityFrameworkCore;

namespace Northstar.Ordering.Api;

public sealed class OrderingDbContext(
    DbContextOptions<OrderingDbContext> options)
    : DbContext(options)
{
    public DbSet<CheckoutSaga> CheckoutSagas =>
        Set<CheckoutSaga>();

    public DbSet<OutboxMessage> OutboxMessages =>
        Set<OutboxMessage>();

    public DbSet<InboxMessage> InboxMessages =>
        Set<InboxMessage>();

    protected override void OnModelCreating(
        ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CheckoutSaga>(saga =>
        {
            saga.HasKey(x => x.Id);
            saga.Property(x => x.Version)
                .IsConcurrencyToken();
        });

        modelBuilder.Entity<OutboxMessage>()
            .HasKey(x => x.Id);

        modelBuilder.Entity<InboxMessage>()
            .HasKey(x => new
            {
                x.MessageId,
                x.Handler
            });
    }
}

public sealed class OutboxMessage
{
    private OutboxMessage() { }

    public Guid Id { get; private set; }
    public string RoutingKey { get; private set; } = "";
    public string Type { get; private set; } = "";
    public string Payload { get; private set; } = "";
    public DateTimeOffset CreatedAt { get; private set; }
    public DateTimeOffset? PublishedAt { get; private set; }

    public static OutboxMessage Create(
        Guid id,
        string routingKey,
        string type,
        string payload,
        DateTimeOffset createdAt)
        => new()
        {
            Id = id,
            RoutingKey = routingKey,
            Type = type,
            Payload = payload,
            CreatedAt = createdAt
        };

    public void MarkPublished(DateTimeOffset now)
        => PublishedAt = now;
}

public sealed class InboxMessage
{
    private InboxMessage() { }

    public Guid MessageId { get; private set; }
    public string Handler { get; private set; } = "";
    public DateTimeOffset ProcessedAt { get; private set; }

    public static InboxMessage Create(
        Guid messageId,
        string handler,
        DateTimeOffset processedAt)
        => new()
        {
            MessageId = messageId,
            Handler = handler,
            ProcessedAt = processedAt
        };
}
