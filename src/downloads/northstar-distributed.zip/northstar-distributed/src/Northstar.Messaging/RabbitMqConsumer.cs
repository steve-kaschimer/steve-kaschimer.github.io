using System.Text.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Northstar.Messaging;

public abstract class RabbitMqConsumer<T>(
    RabbitMqConnection connection,
    string queueName,
    string routingKey)
    : BackgroundService
{
    protected abstract Task HandleAsync(
        T message,
        CancellationToken cancellationToken);

    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        var conn = await connection.GetAsync();

        var channel =
            await conn.CreateChannelAsync(
                cancellationToken: stoppingToken);

        await channel.ExchangeDeclareAsync(
            "northstar",
            ExchangeType.Direct,
            durable: true,
            autoDelete: false,
            cancellationToken: stoppingToken);

        var deadLetterExchange =
            $"{queueName}.dlx";

        await channel.ExchangeDeclareAsync(
            deadLetterExchange,
            ExchangeType.Direct,
            durable: true,
            autoDelete: false,
            cancellationToken: stoppingToken);

        var deadLetterQueue =
            $"{queueName}.dead";

        await channel.QueueDeclareAsync(
            queue: deadLetterQueue,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: null,
            cancellationToken: stoppingToken);

        await channel.QueueBindAsync(
            deadLetterQueue,
            deadLetterExchange,
            routingKey,
            arguments: null,
            cancellationToken: stoppingToken);

        var queueArguments =
            new Dictionary<string, object?>
            {
                ["x-dead-letter-exchange"] =
                    deadLetterExchange,
                ["x-dead-letter-routing-key"] =
                    routingKey
            };

        await channel.QueueDeclareAsync(
            queue: queueName,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: queueArguments,
            cancellationToken: stoppingToken);

        await channel.QueueBindAsync(
            queueName,
            "northstar",
            routingKey,
            arguments: null,
            cancellationToken: stoppingToken);

        await channel.BasicQosAsync(
            prefetchSize: 0,
            prefetchCount: 8,
            global: false,
            cancellationToken: stoppingToken);

        var consumer =
            new AsyncEventingBasicConsumer(channel);

        consumer.ReceivedAsync += async (_, ea) =>
        {
            using var activity =
                NorthstarTelemetry.ActivitySource.StartActivity(
                    $"consume {routingKey}",
                    ActivityKind.Consumer);

            try
            {
                // RabbitMQ .NET client 7 requires the payload
                // to be copied/deserialized before the handler returns.
                var bytes = ea.Body.ToArray();

                var message =
                    JsonSerializer.Deserialize<T>(bytes)
                    ?? throw new InvalidOperationException(
                        "Message could not be deserialized.");

                await HandleAsync(
                    message,
                    stoppingToken);

                NorthstarTelemetry.ConsumedMessages.Add(
                    1,
                    new KeyValuePair<string, object?>(
                        "messaging.routing_key",
                        routingKey));

                await channel.BasicAckAsync(
                    ea.DeliveryTag,
                    multiple: false,
                    stoppingToken);
            }
            catch
            {
                NorthstarTelemetry.FailedMessages.Add(
                    1,
                    new KeyValuePair<string, object?>(
                        "messaging.routing_key",
                        routingKey));

                var redelivered = ea.Redelivered;

                // Teaching policy:
                // first failure requeues once;
                // a redelivery failure is rejected to the DLX.
                await channel.BasicNackAsync(
                    ea.DeliveryTag,
                    multiple: false,
                    requeue: !redelivered,
                    stoppingToken);
            }
        };

        await channel.BasicConsumeAsync(
            queue: queueName,
            autoAck: false,
            consumer: consumer,
            cancellationToken: stoppingToken);

        await Task.Delay(
            Timeout.Infinite,
            stoppingToken);
    }
}
