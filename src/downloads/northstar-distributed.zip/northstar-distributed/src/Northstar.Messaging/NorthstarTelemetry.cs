using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace Northstar.Messaging;

public static class NorthstarTelemetry
{
    public static readonly ActivitySource ActivitySource =
        new("Northstar.Messaging");

    public static readonly Meter Meter =
        new("Northstar.Messaging");

    public static readonly Counter<long> PublishedMessages =
        Meter.CreateCounter<long>(
            "northstar.messaging.published");

    public static readonly Counter<long> ConsumedMessages =
        Meter.CreateCounter<long>(
            "northstar.messaging.consumed");

    public static readonly Counter<long> FailedMessages =
        Meter.CreateCounter<long>(
            "northstar.messaging.failed");
}
