using RabbitMQ.Client;

namespace Northstar.Messaging;

public sealed class RabbitMqConnection : IAsyncDisposable
{
    private IConnection? _connection;

    public async Task<IConnection> GetAsync()
    {
        if (_connection is not null)
            return _connection;

        var host =
            Environment.GetEnvironmentVariable("RABBITMQ_HOST")
            ?? "localhost";

        var factory = new ConnectionFactory
        {
            HostName = host,
            UserName = "guest",
            Password = "guest",
            AutomaticRecoveryEnabled = true
        };

        _connection =
            await factory.CreateConnectionAsync();

        return _connection;
    }

    public async ValueTask DisposeAsync()
    {
        if (_connection is not null)
            await _connection.DisposeAsync();
    }
}
