using System.Text.Json;
using RabbitMQ.Client;

namespace Northstar.Messaging;

public sealed class RabbitMqBus(
    RabbitMqConnection connection)
{
    public async Task PublishAsync<T>(
        string routingKey,
        T message,
        CancellationToken cancellationToken)
    {
        using var activity =
            NorthstarTelemetry.ActivitySource.StartActivity(
                $"publish {routingKey}",
                ActivityKind.Producer);

        var conn = await connection.GetAsync();

        await using var channel =
            await conn.CreateChannelAsync(
                cancellationToken: cancellationToken);

        await channel.ExchangeDeclareAsync(
            exchange: "northstar",
            type: ExchangeType.Direct,
            durable: true,
            autoDelete: false,
            cancellationToken: cancellationToken);

        var body =
            JsonSerializer.SerializeToUtf8Bytes(message);

        var properties = new BasicProperties
        {
            ContentType = "application/json",
            DeliveryMode = DeliveryModes.Persistent,
            MessageId = message?.GetType()
                .GetProperty("MessageId")
                ?.GetValue(message)
                ?.ToString()
        };

        await channel.BasicPublishAsync(
            exchange: "northstar",
            routingKey: routingKey,
            mandatory: true,
            basicProperties: properties,
            body: body,
            cancellationToken: cancellationToken);

        NorthstarTelemetry.PublishedMessages.Add(
            1,
            new KeyValuePair<string, object?>(
                "messaging.routing_key",
                routingKey));
    }
}
