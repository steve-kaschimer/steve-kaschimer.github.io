---
title: "Lab 7: When a Domain Event Needs a Delivery Guarantee"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v8-integration-event-pressure"
status: "draft"
---

# Lab 7: When a Domain Event Needs a Delivery Guarantee

v7 gave us a useful local fact:

```text
OrderPlaced
```

Now Fulfillment becomes a separate operational concern.

The requirement changes from:

> run some code after order placement

to:

> Fulfillment must eventually hear about every placed order.

Those are not the same guarantee.

## Domain Event vs. Integration Event

The domain event remains internal:

```text
OrderPlaced
```

A handler translates it into a distributed contract:

```text
OrderPlacedIntegrationEvent
```

That keeps the internal domain model separate from the external contract.

## The Naive Implementation

This stage publishes after commit:

```text
COMMIT Order
    |
publish message
```

Under normal conditions, it works.

That is why the bug is dangerous.

## Break It

Configure publishing to fail.

Now:

```text
Order committed ✓
Integration event published ✗
```

No amount of retry inside the current request can prove recovery after a process crash.

The system has crossed a boundary where two independent durable systems must be coordinated.

## The Pattern We Have Earned

Transactional Outbox.

The next stage will change the sequence to:

```text
BEGIN
  save Order
  save OutboxMessage
COMMIT

later:
  publish OutboxMessage
```

The broker will no longer be part of the order transaction.

That is the key design move.
