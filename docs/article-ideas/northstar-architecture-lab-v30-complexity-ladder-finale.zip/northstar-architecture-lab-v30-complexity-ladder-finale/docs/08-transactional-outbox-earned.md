---
title: "Lab 8: Transactional Outbox Makes the Integration Event Durable"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v9-transactional-outbox"
status: "draft"
---

# Lab 8: Transactional Outbox Makes the Integration Event Durable

v8 deliberately performed:

```text
save Order
publish Integration Event
```

That contained a hole.

If the first operation succeeded and the second never did, Ordering and Fulfillment disagreed about reality.

## The New Transaction

v9 changes the write path:

```text
BEGIN

Order row
Outbox row

COMMIT
```

Both durable facts now succeed or fail together.

## Why the Broker Is Not in the Transaction

The application does not attempt a distributed transaction across SQLite and a broker.

Instead, it stores the intent to publish locally.

A background dispatcher owns the remote operation.

## Break It

Make publishing fail.

The dispatcher records the failure.

The Outbox row remains pending.

Restore publishing.

The dispatcher tries again.

The message survives the outage because the database already owns it.

## We Did Not Achieve Exactly Once

Imagine:

```text
publish succeeds
process crashes
PublishedAt not saved
```

The dispatcher will publish again.

So the guarantee is:

```text
at least once
```

That is why the next pressure belongs on the receiving side.

## Next

We will create a Fulfillment consumer and deliberately deliver the same message twice.

Then Inbox / Idempotent Consumer will earn its place.
