---
title: "Lab 6: Domain Events Separate Facts From Reactions"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v7-domain-events"
status: "draft"
---

# Lab 6: Domain Events Separate Facts From Reactions

v6 showed a natural growth pattern:

```text
PlaceOrder
  |
  + confirmation
  + loyalty
  + fulfillment
  + analytics
```

The command had become the registry of everybody who cared about order placement.

## The Refactor

The Order aggregate now records:

```text
OrderPlaced
```

That is a domain fact.

It does not know:

```text
email
loyalty implementation
analytics
fulfillment implementation
```

Application handlers react independently.

## What Improved

Adding another in-process reaction no longer requires editing `PlaceOrder`.

The business occurrence is now explicit and testable.

The aggregate says:

```text
this happened
```

The application decides:

```text
who cares
```

## What Did Not Improve

Durability.

This stage dispatches after the database commit.

That means this failure is possible:

```text
Order commit succeeds
Process crashes
Domain-event handler never runs
```

This is not a bug in Domain Events.

It is the boundary of the pattern.

## The Next Big Step

Some reactions are merely local application behavior.

Others eventually become external commitments:

```text
Fulfillment service must know
Analytics pipeline must know
```

Once that requirement becomes durable and cross-process, in-memory dispatch is not enough.

That pressure will earn:

```text
Integration Event
Message Broker
Transactional Outbox
```

But not yet.

First, we needed to separate the fact from the reactions.
