---
title: "Lab 5: When One Successful Command Creates Too Many Reactions"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v6-reaction-pressure"
status: "draft"
---

# Lab 5: When One Successful Command Creates Too Many Reactions

Northstar's `PlaceOrder` command now succeeds.

Then the business asks for consequences:

```text
confirmation
loyalty
fulfillment
analytics
```

So we call them.

That is not bad engineering.

It is the simplest implementation.

## The New Shape

`PlaceOrder` now coordinates:

```text
domain behavior
persistence
confirmation
loyalty
fulfillment
analytics
```

The handler is becoming a list of reactions.

## The Hidden Coupling

If Analytics is removed, `PlaceOrder` changes.

If Loyalty adds a new dependency, `PlaceOrder` changes.

If Fulfillment becomes asynchronous, `PlaceOrder` changes.

The command knows too much about who cares that the order was placed.

## The Question

The domain knows this fact:

```text
OrderPlaced
```

Why should the aggregate or command know every consumer of that fact?

## Next

The next stage introduces a Domain Event:

```text
OrderPlaced
```

The aggregate records the fact.

Handlers react.

The application dispatches those reactions around the Unit of Work boundary.

We will still remain in-process.

No broker yet.

That distinction matters.
