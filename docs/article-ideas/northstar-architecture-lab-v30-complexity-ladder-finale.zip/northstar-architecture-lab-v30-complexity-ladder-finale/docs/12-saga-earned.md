---
title: "Lab 12: Saga Makes Distributed Workflow State Explicit"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v13-saga"
status: "draft"
---

# Lab 12: Saga Makes Distributed Workflow State Explicit

v12 proved the problem:

```text
Inventory reserved
Payment declined
```

There is no global rollback.

v13 introduces a durable workflow object:

```text
CheckoutSaga
```

## The Saga Remembers Progress

The workflow records:

```text
InventoryReservationId
PaymentAuthorizationId
Status
StartedAt
CompletedAt
```

That gives the system a durable answer to:

> Where is this checkout right now?

## Compensation Is a Business Action

When Payment declines:

```text
ReleaseInventory
```

is not a rollback.

It is a new operation that compensates for the earlier reservation.

The world moved forward.

## Why This Matters Operationally

An operator can now inspect the Saga and see:

```text
Started
InventoryReserved
PaymentDeclined
Compensated
```

The recovery path is part of the model rather than hidden in logs.

## What Is Still Simplified

The coordinator still calls Inventory and Payment in-process.

That is intentional.

We wanted to learn the workflow semantics before adding broker mechanics.

The next evolution can distribute those Saga commands and replies using the messaging infrastructure we already built.

## Lesson

Saga was not introduced because the application had multiple services.

It was introduced because one business transaction crossed independent commit boundaries and partial success required explicit recovery.
