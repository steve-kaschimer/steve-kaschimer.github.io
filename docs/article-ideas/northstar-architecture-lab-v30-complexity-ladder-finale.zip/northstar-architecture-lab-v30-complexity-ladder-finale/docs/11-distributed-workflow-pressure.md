---
title: "Lab 11: When One Business Operation Stops Being One Transaction"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v12-distributed-workflow-pressure"
status: "draft"
---

# Lab 11: When One Business Operation Stops Being One Transaction

Checkout now spans three independently committed responsibilities:

```text
Order
Inventory
Payment
```

The coordinator calls them in sequence.

Under normal conditions, everything works.

## Break It

Configure Payment to decline.

The resulting state is:

```text
Order exists
InventoryReservation = Reserved
PaymentAuthorization = Declined
```

The HTTP request failed from the customer's perspective.

But some business effects already happened.

## Why Rollback No Longer Works

The inventory reservation committed in a separate operation.

There is no local transaction that can rewind it automatically.

The workflow itself now needs state and recovery behavior.

## The Question

What should happen after Payment declines?

The business answer is:

```text
Release Inventory
Cancel Checkout
```

That is a compensating action.

## Next

v13 introduces a Saga state machine.

The workflow becomes a durable concept rather than a sequence hidden inside one coordinator method.
