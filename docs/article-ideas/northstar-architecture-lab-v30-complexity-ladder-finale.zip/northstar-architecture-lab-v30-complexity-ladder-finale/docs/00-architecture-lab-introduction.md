# Architecture Lab: Northstar Commerce

Northstar Commerce is the evolving companion application for Volume II.

The baseline is deliberately simple:

```text
ASP.NET Core -> EF Core -> SQLite
```

We will not pre-install future architecture.

Each new pattern must answer a concrete problem introduced by a requirement, scale constraint, or failure scenario.

## Lab Rule

> Complexity must be earned.

## Baseline Experiment

Read `Features/Orders/PlaceOrder.cs`.

The use case currently owns validation, product lookup, business decisions, calculation, persistence, and response creation.

That is acceptable while the rules are simple.

The next experiment will deliberately increase business complexity until the limitations become visible.

Then we will evolve the model.
