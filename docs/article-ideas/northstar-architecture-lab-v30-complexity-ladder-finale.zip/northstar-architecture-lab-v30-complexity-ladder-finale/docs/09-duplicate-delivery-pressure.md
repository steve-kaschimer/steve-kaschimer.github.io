---
title: "Lab 9: At-Least-Once Delivery Means Duplicate Effects Are Your Problem"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v10-duplicate-consumer-pressure"
status: "draft"
---

# Lab 9: At-Least-Once Delivery Means Duplicate Effects Are Your Problem

Transactional Outbox solved message loss.

It did not solve duplicate delivery.

That is expected.

## Reproduce It

Send the same integration event twice:

```json
{
  "eventId": "11111111-1111-1111-1111-111111111111",
  "orderId": "22222222-2222-2222-2222-222222222222",
  "customerEmail": "reader@example.com",
  "total": 100,
  "occurredAt": "2026-08-14T20:00:00Z"
}
```

to:

```text
POST /lab/fulfillment/deliver
```

twice.

Then query:

```text
GET /lab/fulfillment/work
```

You will see two work records with the same source event identity.

## The Important Shift

The publisher can no longer guarantee:

```text
you will receive this exactly once
```

The consumer must guarantee:

```text
receiving it again is harmless
```

## Next

We will add an Inbox.

The consumer will persist:

```text
MessageId processed
```

in the same transaction as:

```text
FulfillmentWork created
```

That atomicity is the whole point.
