---
title: "Lab 10: Inbox Makes Duplicate Delivery Harmless"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v11-inbox-idempotent-consumer"
status: "draft"
---

# Lab 10: Inbox Makes Duplicate Delivery Harmless

v10 delivered one `OrderPlacedIntegrationEvent` twice.

Fulfillment created two work items.

That is exactly what at-least-once delivery allows unless the consumer protects itself.

## The Inbox

v11 records:

```text
MessageId
Handler
ProcessedAt
```

with a unique key.

The handler commits:

```text
Inbox marker
+
Fulfillment work
```

together.

## Why the Transaction Matters

This would be unsafe:

```text
create fulfillment work
COMMIT

record inbox
COMMIT
```

A crash between commits could repeat the business effect.

Likewise:

```text
record inbox
COMMIT

create fulfillment work
```

could permanently suppress work that never happened.

The marker and the effect are one local consistency boundary.

## Why the Unique Constraint Matters

Two duplicates can arrive simultaneously.

Both can observe:

```text
not processed yet
```

The database must decide which one wins.

Application-level `if` checks are not enough.

## Try It

Post the same event twice.

Then inspect:

```text
/lab/fulfillment/inbox
/lab/fulfillment/work
```

You should see:

```text
one Inbox row
one FulfillmentWork row
```

## Pattern Composition

Northstar now has:

```text
Ordering transaction
  |
Outbox
  |
at-least-once publish
  |
Fulfillment
  |
Inbox
  |
business effect
```

Outbox protects the producer.

Inbox protects the consumer.

Together they form a reliable local-to-local bridge without pretending the distributed system is globally atomic.

## Next

Now we can make the workflow genuinely distributed.

Placing an order will require:

```text
reserve inventory
authorize payment
schedule fulfillment
```

Each participant owns its own transaction.

Some steps can fail after earlier steps have committed.

That is the pressure Saga exists to solve.
