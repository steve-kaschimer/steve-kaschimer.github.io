---
title: "Lab 28: Sidecar Moves Runtime Capability Beside the App"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v29-sidecar"
status: "draft"
---

# Lab 28: Sidecar Moves Runtime Capability Beside the App

A Sidecar runs next to the application rather than inside it or as one shared central service.

## Why That Can Help

Some capabilities are cross-cutting:

```text
proxying
telemetry forwarding
secret refresh
protocol adaptation
```

A sidecar can provide them in a language-neutral process.

## The Trade

Library:

```text
same process
fast
simple lifecycle
language-specific
```

Sidecar:

```text
separate process
local network hop
language-neutral
independent runtime
extra failure mode
```

The separate process is the feature and the cost.

## Failure Semantics

This lab deliberately treats the sidecar as optional.

If it is unavailable:

```text
application remains healthy
feature degrades
```

That may be correct for telemetry or optional proxying.

It would be wrong for a security-critical sidecar that must fail closed.

## The Lesson

Do not ask:

> Can this capability be a sidecar?

Ask:

> Does process isolation or language-neutral reuse justify another runtime component on every instance?

If not, a library or platform feature may be simpler.
