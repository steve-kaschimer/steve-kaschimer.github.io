# Northstar v29 — Sidecar

This lab demonstrates a small sidecar pattern:

```text
Northstar App
    |
localhost HTTP
    |
Telemetry/Proxy Sidecar
    |
External endpoint
```

The point is not to build a service mesh.

The point is to show the trade:

```text
cross-cutting capability
moves out of process
```

without becoming a shared remote service.

## Run

Start the sidecar:

```bash
dotnet run --project src/Northstar.Sidecar
```

Start the app:

```bash
dotnet run --project src/Northstar.SidecarDemo.Api
```

Call:

```bash
curl http://localhost:5200/proxy-demo
```

## Failure Experiment

Stop the sidecar.

The API returns a controlled degraded response instead of crashing the whole application.

That distinction matters:

> Optional infrastructure should not accidentally become a hard availability dependency.
