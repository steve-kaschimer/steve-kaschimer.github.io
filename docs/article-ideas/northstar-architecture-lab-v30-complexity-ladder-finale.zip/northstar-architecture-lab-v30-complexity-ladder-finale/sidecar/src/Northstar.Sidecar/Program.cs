var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

app.MapPost(
    "/forward",
    (ForwardRequest request) =>
        Results.Ok(new
        {
            forwarded = true,
            request.Operation,
            receivedAt = DateTimeOffset.UtcNow
        }));

app.Run("http://localhost:5300");

public sealed record ForwardRequest(
    string Operation);
