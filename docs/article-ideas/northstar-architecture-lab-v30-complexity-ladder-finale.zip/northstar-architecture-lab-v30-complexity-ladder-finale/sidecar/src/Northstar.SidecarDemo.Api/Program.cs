var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient(
    "sidecar",
    client =>
    {
        client.BaseAddress =
            new Uri("http://localhost:5300");

        client.Timeout =
            TimeSpan.FromSeconds(1);
    });

var app = builder.Build();

app.MapGet(
    "/proxy-demo",
    async (
        IHttpClientFactory clients,
        CancellationToken cancellationToken) =>
    {
        var client =
            clients.CreateClient("sidecar");

        try
        {
            var response =
                await client.PostAsJsonAsync(
                    "/forward",
                    new
                    {
                        operation = "proxy-demo"
                    },
                    cancellationToken);

            response.EnsureSuccessStatusCode();

            return Results.Ok(
                await response.Content
                    .ReadFromJsonAsync<object>(
                        cancellationToken:
                            cancellationToken));
        }
        catch (Exception exception)
            when (exception is HttpRequestException
                  or TaskCanceledException)
        {
            return Results.Ok(new
            {
                forwarded = false,
                degraded = true,
                reason = "Sidecar unavailable."
            });
        }
    });

app.Run("http://localhost:5200");
