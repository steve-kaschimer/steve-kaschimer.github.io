---
title: "Lab 27: Contract Tests Catch Boundary Breakage Early"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v28-contract-testing"
status: "draft"
---

# Lab 27: Contract Tests Catch Boundary Breakage Early

Northstar now has boundaries that may evolve independently.

That creates a question:

> How do we know a provider change still satisfies what consumers rely on?

## The Consumer View

The consumer cares about:

```text
OrderId
ShipmentReference
Status
```

It does not care about:

```text
internalProviderVersion
legacy status code
database schema
implementation class
```

The contract should capture only the dependency that actually exists.

## Provider Verification

The provider test starts the real ASP.NET Core app and verifies the response shape.

That gives us boundary-level feedback without requiring a full end-to-end environment.

## Why Not Share DTO Packages?

A shared DTO assembly may align types while still missing:

```text
status codes
serialization details
optional/required semantics
route behavior
```

And it tightly couples release cycles.

The contract should test the actual boundary.

## Why Not Test Everything?

Overspecified contracts become another form of coupling.

If the consumer does not use a field, do not freeze it accidentally.

## The Lesson

Consumer-driven contract testing gives independent teams confidence to evolve APIs while catching breaking changes before those versions meet in production.
