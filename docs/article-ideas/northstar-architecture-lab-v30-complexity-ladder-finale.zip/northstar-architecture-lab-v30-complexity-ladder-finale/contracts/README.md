# Northstar v28 — Consumer-Driven Contract Testing

Northstar now has independently evolving boundaries.

That creates a new failure mode:

```text
Provider deploys successfully
Consumer deploys successfully
Integration breaks
```

Contract testing moves that feedback into CI.

## Scenario

A public Shipping/Fulfillment consumer depends on:

```json
{
  "orderId": "...",
  "shipmentReference": "...",
  "status": "Shipped"
}
```

The consumer does **not** care about internal legacy fields or provider implementation.

The contract test records exactly that dependency.

## Run

```bash
dotnet restore
dotnet test
```

## What This Lab Demonstrates

- consumer-owned expectations;
- provider verification;
- avoiding shared DTO coupling;
- contract scope limited to what the consumer actually uses.

The goal is not to replace all integration or end-to-end tests.

The goal is to catch boundary incompatibility before deployment.
