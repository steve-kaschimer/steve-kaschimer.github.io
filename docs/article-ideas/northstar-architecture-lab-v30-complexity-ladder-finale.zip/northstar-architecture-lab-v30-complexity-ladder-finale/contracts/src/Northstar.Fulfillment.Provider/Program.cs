var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

app.MapGet(
    "/shipping/{orderId:guid}",
    (Guid orderId) =>
        Results.Ok(new
        {
            orderId,
            shipmentReference =
                $"SHP-{orderId.ToString()[..6]}",
            status = "Shipped",
            internalProviderVersion = "v3"
        }));

app.Run();

public partial class Program;
