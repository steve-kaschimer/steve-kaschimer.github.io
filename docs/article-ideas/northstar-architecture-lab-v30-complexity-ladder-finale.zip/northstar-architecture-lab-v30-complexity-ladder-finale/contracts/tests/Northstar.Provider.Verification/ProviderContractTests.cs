using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Northstar.Provider.Verification;

public sealed class ProviderContractTests
    : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public ProviderContractTests(
        WebApplicationFactory<Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task Provider_satisfies_shipping_consumer_contract()
    {
        var orderId = Guid.NewGuid();

        var response =
            await _client.GetAsync(
                $"/shipping/{orderId}");

        Assert.Equal(
            HttpStatusCode.OK,
            response.StatusCode);

        var body =
            await response.Content
                .ReadFromJsonAsync<ShippingContractResponse>();

        Assert.NotNull(body);
        Assert.Equal(orderId, body.OrderId);
        Assert.False(
            string.IsNullOrWhiteSpace(
                body.ShipmentReference));
        Assert.Equal(
            "Shipped",
            body.Status);
    }

    private sealed record ShippingContractResponse(
        Guid OrderId,
        string ShipmentReference,
        string Status);
}
