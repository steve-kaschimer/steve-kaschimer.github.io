namespace Northstar.Consumer.Contracts;

public sealed record FulfillmentContract(
    Guid OrderId,
    string ShipmentReference,
    string Status);

public sealed class FulfillmentConsumerContractTests
{
    [Fact]
    public void Consumer_depends_on_three_fields_only()
    {
        var contract =
            new FulfillmentContract(
                Guid.NewGuid(),
                "SHP-ABC123",
                "Shipped");

        Assert.False(
            string.IsNullOrWhiteSpace(
                contract.ShipmentReference));

        Assert.Equal(
            "Shipped",
            contract.Status);
    }
}
