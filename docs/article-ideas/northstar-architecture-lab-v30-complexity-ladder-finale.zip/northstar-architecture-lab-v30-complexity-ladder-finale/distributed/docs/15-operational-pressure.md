---
title: "Lab 15: Correct but Unhealthy"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v16-operational-pressure"
status: "draft"
---

# Lab 15: Correct but Unhealthy

Northstar can now survive duplicate delivery and broker interruptions without corrupting business state.

Then Payment becomes slow.

Nothing is technically inconsistent.

The customer still waits.

Operations still have a problem.

## Correctness vs. Health

Distributed systems need both.

```text
Correctness:
Did we lose or duplicate business effects?

Health:
How long is the workflow taking?
Is progress being made?
Are dependencies failing?
Are retries amplifying load?
```

## A Saga Deadline

The Saga now records:

```text
DeadlineAt
```

A monitor marks workflows that exceed it as:

```text
TimedOut
```

That gives operators a durable answer to:

> Which workflows are stuck?

## Controlled Dependency Failure

The Payment worker can now simulate:

```text
latency
outage
decline
```

Those are three different conditions.

They should not all receive the same resilience policy.

## Next

v17 adds:

- bounded Retry with jitter;
- Circuit Breaker;
- timeout budgets;
- dead-letter topology;
- OpenTelemetry traces and metrics.

The key lesson is that these are not "cloud features."

They are responses to observable failure modes.
