---
title: "Lab 17: Dead Lettering Stops Poison Work From Owning the Queue"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v18-dead-letter-recovery"
status: "draft"
---

# Lab 17: Dead Lettering Stops Poison Work From Owning the Queue

Retries only make sense while another attempt might succeed.

A permanently failing message must eventually leave the normal processing path.

## The Failure Loop

Without a DLQ:

```text
receive
fail
requeue
receive
fail
requeue
...
```

Healthy work competes with poison work forever.

## The New Topology

Each queue now has:

```text
<queue>.dlx
<queue>.dead
```

After one redelivery failure, the message is rejected and dead-lettered.

## What DLQ Does Not Solve

Dead-lettering does not fix the business process.

It gives operations a durable place to inspect the failure.

The pattern is incomplete without ownership.

## Replay Safety

Because consumers already use Inbox/idempotent processing, replay is much safer.

That is another example of patterns composing:

```text
DLQ
  +
Idempotent Consumer
```

## Lesson

A queue should carry work that still has a reasonable chance of succeeding.

Dead-lettering protects throughput by moving permanently unhealthy work out of that path while preserving it for diagnosis.
