---
title: "Lab 13: The Saga Crosses the Network"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v14-async-saga-rabbitmq"
status: "draft"
---

# Lab 13: The Saga Crosses the Network

The previous Saga was intentionally in-process.

That allowed us to understand the business workflow before introducing transport complexity.

Now the same state machine crosses RabbitMQ.

## What Changed

Ordering no longer invokes:

```text
InventoryService.Reserve()
PaymentService.Authorize()
```

Instead it emits commands:

```text
ReserveInventory
AuthorizePayment
ReleaseInventory
```

Participants reply with facts:

```text
InventoryReserved
PaymentAuthorized
PaymentDeclined
InventoryReleased
```

## What Did Not Change

The Saga still asks the same business questions:

```text
What step completed?
What step comes next?
If Payment fails, what compensates Inventory?
When is the workflow complete?
```

Transport changed.

Workflow semantics did not.

## Pattern Composition

This stage is where the earlier labs converge.

```text
Ordering
  |
Saga state + Outbox
  |
RabbitMQ
  |
Inventory / Payment
  |
Inbox
  |
local business effect
  |
reply message
```

The Saga is not replacing Outbox or Inbox.

It relies on the same local-consistency ideas.

## Manual Acknowledgements

Consumers acknowledge messages only after processing.

If a worker dies before acknowledgement, RabbitMQ can redeliver the message.

That is why each worker has an Inbox.

The redelivery is expected.

The duplicate business effect is not.

## Break It: Worker Down

Stop Inventory.

Start a checkout.

Ordering has already accepted the workflow.

The command waits in the queue.

Restart Inventory.

The Saga continues.

This is a fundamentally different availability model from the earlier synchronous coordinator.

## Break It: Payment Decline

Configure Payment to decline.

The Saga receives:

```text
PaymentDeclined
```

It does not roll back history.

It emits:

```text
ReleaseInventory
```

After:

```text
InventoryReleased
```

the Saga becomes:

```text
Compensated
```

## What Is Still Imperfect

The Inventory and Payment workers currently persist their Inbox/business effect before publishing the reply directly.

That creates a smaller version of the same dual-write problem we already learned.

A fully hardened implementation would give **each participant its own Outbox**, so:

```text
Inbox
Business effect
Reply Outbox
```

commit together.

That is the next refinement—not a new pattern, but applying the pattern composition consistently at every transactional boundary.

## Lesson

Distributed architecture is recursive.

The reliability rule we learned in Ordering applies again inside every participant.

Patterns do not disappear when we cross a service boundary.

They repeat at each local consistency boundary.
