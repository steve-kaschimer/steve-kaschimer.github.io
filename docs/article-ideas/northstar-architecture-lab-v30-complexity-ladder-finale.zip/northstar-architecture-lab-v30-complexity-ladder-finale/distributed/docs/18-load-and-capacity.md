---
title: "Lab 18: Load Is an Architectural Force"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v19-load-capacity"
status: "draft"
---

# Lab 18: Load Is an Architectural Force

A correct system can still fail because it accepts more work than its dependencies can process.

Northstar now treats capacity explicitly.

## Queue-Based Load Leveling

RabbitMQ is the buffer.

The producer and consumer no longer need identical instantaneous throughput.

That buys stability at the cost of queueing latency.

## Competing Consumers

Multiple worker instances can drain the same queue in parallel.

This increases throughput until another bottleneck becomes dominant.

That is why "add workers" is not an infinite scaling strategy.

## Bulkhead

Payment concurrency is bounded.

A slow Payment dependency can consume only its allocated permits and queue.

It cannot create unbounded in-flight work.

## Rate Limiting

The API rejects excess admission before the system accepts work it cannot responsibly handle.

The result is explicit backpressure:

```text
429
```

rather than hidden overload.

## The Combined Model

```text
Client
  |
Rate Limit
  |
Ordering
  |
Queue
  |
Competing Consumers
  |
Bulkhead
  |
Payment dependency
```

Each control acts at a different boundary.

## Lesson

Capacity is not just an infrastructure sizing problem.

It is part of application behavior.

A production architecture must decide:

```text
what work to admit
what work to buffer
what work to parallelize
what work to reject
```

Those decisions are architecture.
