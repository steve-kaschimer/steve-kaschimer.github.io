---
title: "Lab 21: Optimistic Concurrency Protects Intent"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v22-optimistic-concurrency"
status: "draft"
---

# Lab 21: Optimistic Concurrency Protects Intent

Northstar now has long-lived workflow state.

That creates a new risk:

```text
Operator reads Saga version 7
Workflow advances to version 8
Operator submits an action based on version 7
```

Without concurrency protection, the stale action may overwrite newer state.

## The Version

`CheckoutSaga` now carries:

```text
Version
```

Every meaningful transition increments it.

EF Core treats the version as a concurrency token.

## Expected Version

The operator endpoint accepts:

```json
{
  "expectedVersion": 7
}
```

If the Saga is now version 8:

```text
409 Conflict
```

The application refuses to pretend the stale decision is still valid.

## Two Layers of Protection

The handler first compares the expected version.

EF Core then still protects the database commit in case another writer changes the row between read and save.

That second layer matters.

## Why Not Lock the Saga?

The interaction may include humans or slow external work.

Holding a database lock for that duration would be fragile and expensive.

Optimistic concurrency lets work proceed independently and detects conflict at commit.

## The Lesson

Concurrency control is not about "who wins."

It is about whether the system may safely apply an action against state that has changed since the caller observed it.

That is a business decision, not merely a database feature.
