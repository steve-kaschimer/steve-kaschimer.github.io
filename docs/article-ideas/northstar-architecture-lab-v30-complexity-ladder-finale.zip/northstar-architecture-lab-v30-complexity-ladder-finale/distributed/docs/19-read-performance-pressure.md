---
title: "Lab 19: When the Read Side Becomes Expensive"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v20-read-performance-pressure"
status: "draft"
---

# Lab 19: When the Read Side Becomes Expensive

Northstar's operations dashboard is useful.

It is also increasingly expensive.

Every refresh asks the database for:

```text
total Saga count
active Saga count
timed-out count
compensated count
average checkout amount
20 slowest workflows
```

The query is legitimate.

The pressure comes from repetition.

## Reproduce It

Run:

```powershell
./scripts/hammer-dashboard.ps1 -Count 200
```

The same dashboard is recomputed over and over.

The data changes much less frequently than it is requested.

## The Question

Must every request see the exact current value?

For an operational dashboard, perhaps a few seconds of staleness is acceptable.

If so, we can trade:

```text
freshness
```

for:

```text
lower database load
lower latency
```

That trade earns caching.

## What We Will Not Do

We will not cache:

```text
payment authorization
inventory reservation
Saga state transitions
```

Those are correctness-sensitive write concerns.

The cache belongs on the read side where stale data is explicitly acceptable.

## Next

v21 introduces Cache-Aside around the dashboard.

But we will also deliberately address:

```text
TTL
staleness
cache miss stampede
invalidation
cache failure
```

because those are the real architecture of caching.
