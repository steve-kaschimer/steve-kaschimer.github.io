---
title: "Lab 16: Resilience Is Observable Policy"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v17-resilience-observability"
status: "draft"
---

# Lab 16: Resilience Is Observable Policy

Northstar is transactionally reliable.

Now it must remain useful when dependencies are slow or unavailable.

## Retry

The Payment worker uses a bounded resilience pipeline:

```text
attempt
backoff + jitter
attempt
backoff + jitter
attempt
give up
```

Retry is only for the simulated transient dependency failure.

A Payment decline is still a business result and is **not retried**.

## Timeout

Each dependency attempt has a bounded wait.

This prevents a slow dependency from holding workflow progress indefinitely.

The Saga has its own broader deadline.

Those are different time boundaries:

```text
attempt timeout
<
Saga deadline
```

## Circuit Breaker

Repeated failures eventually open the circuit.

Then Payment stops calling the unhealthy dependency temporarily and fails fast.

This protects both the worker and the dependency from a retry storm.

## Dead Letter

RabbitMQ supports dead-letter exchanges for rejected, expired, or otherwise dead-lettered messages.

In a production deployment, poison commands should be routed to a DLQ after bounded attempts instead of being requeued forever.

The teaching consumer currently requeues on handler failure so you can observe redelivery.

The next hardening step is to attach a retry/dead-letter topology and operational replay workflow.

## OpenTelemetry

The messaging library now creates:

```text
Producer Activity
Consumer Activity
published counter
consumed counter
failed counter
```

OpenTelemetry collects those standard .NET `ActivitySource` and `Meter` signals.

This makes a workflow visible across:

```text
Ordering
RabbitMQ
Inventory
Ordering
RabbitMQ
Payments
Ordering
```

## Why Observability Comes Now

Tracing was useful earlier.

It becomes essential once asynchronous workflows span several processes.

Without it, a stuck Saga is a pile of unrelated log entries.

With trace/message/Saga identity, operators can reconstruct the causal path.

## Break It

### Slow Payment

```text
NORTHSTAR_PAYMENT_DELAY_MS=10000
```

Watch attempt timeouts and the Saga deadline.

### Failing Payment

```text
NORTHSTAR_PAYMENT_FAIL=true
```

Watch:

```text
retry
retry
retry
circuit opens
```

### Recover Payment

Remove the failure flag.

After the break interval, the circuit permits probe traffic and can close.

## The Lesson

Resilience patterns are not decorations around `HttpClient`.

They encode explicit policy:

```text
How long will we wait?
What is transient?
How many extra attempts can we afford?
When should we stop calling?
What happens to work that never succeeds?
How will an operator see any of this?
```

The policy must be observable or it cannot be operated safely.
