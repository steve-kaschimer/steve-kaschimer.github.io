using Northstar.Features.Checkout.Saga;

namespace Northstar.Api.Tests;

public sealed class SagaTests
{
    [Fact]
    public void Payment_decline_can_drive_compensation_state()
    {
        var saga = new CheckoutSaga(
            Guid.NewGuid(),
            Guid.NewGuid(),
            DateTimeOffset.UtcNow);

        var reservationId = Guid.NewGuid();
        var paymentId = Guid.NewGuid();

        saga.MarkInventoryReserved(
            reservationId);

        saga.MarkPaymentDeclined(
            paymentId);

        saga.MarkCompensated(
            DateTimeOffset.UtcNow);

        Assert.Equal(
            CheckoutSagaStatus.Compensated,
            saga.Status);

        Assert.Equal(
            reservationId,
            saga.InventoryReservationId);

        Assert.Equal(
            paymentId,
            saga.PaymentAuthorizationId);
    }
}
