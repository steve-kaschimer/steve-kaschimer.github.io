using Northstar.Features.Fulfillment;

namespace Northstar.Api.Tests;

public sealed class DuplicateConsumerPressureTests
{
    [Fact]
    public void Fulfillment_work_preserves_source_event_identity()
    {
        var eventId = Guid.NewGuid();

        var work = new FulfillmentWork(
            Guid.NewGuid(),
            eventId,
            Guid.NewGuid(),
            DateTimeOffset.UtcNow);

        Assert.Equal(
            eventId,
            work.SourceEventId);
    }

    [Fact]
    public void V10_has_no_uniqueness_rule_for_source_event()
    {
        // Two FulfillmentWork instances may currently be created
        // from the same SourceEventId. This test documents the pressure.
        var eventId = Guid.NewGuid();

        var first = new FulfillmentWork(
            Guid.NewGuid(),
            eventId,
            Guid.NewGuid(),
            DateTimeOffset.UtcNow);

        var second = new FulfillmentWork(
            Guid.NewGuid(),
            eventId,
            Guid.NewGuid(),
            DateTimeOffset.UtcNow);

        Assert.Equal(
            first.SourceEventId,
            second.SourceEventId);
    }
}
