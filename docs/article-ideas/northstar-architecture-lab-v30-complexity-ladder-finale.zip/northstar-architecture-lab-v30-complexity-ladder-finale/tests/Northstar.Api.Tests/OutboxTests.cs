using Northstar.Infrastructure.Messaging;

namespace Northstar.Api.Tests;

public sealed class OutboxTests
{
    [Fact]
    public void New_outbox_message_is_pending()
    {
        var message = OutboxMessage.Create(
            Guid.NewGuid(),
            nameof(OrderPlacedIntegrationEvent),
            "{}",
            DateTimeOffset.UtcNow);

        Assert.Null(message.PublishedAt);
    }

    [Fact]
    public void Published_message_records_completion()
    {
        var message = OutboxMessage.Create(
            Guid.NewGuid(),
            nameof(OrderPlacedIntegrationEvent),
            "{}",
            DateTimeOffset.UtcNow);

        var publishedAt = DateTimeOffset.UtcNow;

        message.MarkPublished(publishedAt);

        Assert.Equal(
            publishedAt,
            message.PublishedAt);
    }
}
