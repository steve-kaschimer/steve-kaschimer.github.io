namespace Northstar.Api.Tests;

public sealed class ReactionPressureTests
{
    [Fact]
    public void Place_order_now_has_multiple_post_commit_reactions()
    {
        var reactions = new[]
        {
            "Confirmation",
            "Loyalty",
            "Fulfillment",
            "Analytics"
        };

        Assert.Equal(4, reactions.Length);
    }
}
