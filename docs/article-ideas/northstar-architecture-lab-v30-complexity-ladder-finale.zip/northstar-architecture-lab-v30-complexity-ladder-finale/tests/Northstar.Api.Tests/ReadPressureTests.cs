using Northstar.Domain.Orders;

namespace Northstar.Api.Tests;

public sealed class ReadPressureTests
{
    [Fact]
    public void Approval_view_needs_only_a_projection_of_order_state()
    {
        var order = Order.Create(
            Guid.NewGuid(),
            "reader@example.com",
            DateTimeOffset.UtcNow);

        order.AddItem(
            Guid.NewGuid(),
            "Architecture Workshop",
            new Money(1_500m),
            quantity: 1,
            maxPurchaseQuantity: 1,
            isDiscontinued: false);

        order.Place();

        Assert.Equal(
            OrderStatus.PendingApproval,
            order.Status);

        // The dashboard only needs:
        // Id, CustomerEmail, Total, Units, CreatedAt.
        //
        // Rehydrating the entire aggregate is correct,
        // but increasingly unnecessary for read-only screens.
        Assert.Single(order.Items);
    }
}
