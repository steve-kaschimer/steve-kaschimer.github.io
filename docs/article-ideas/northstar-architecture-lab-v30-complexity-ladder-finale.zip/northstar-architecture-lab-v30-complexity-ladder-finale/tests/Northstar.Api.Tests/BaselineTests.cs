using Northstar.Domain.Orders;

namespace Northstar.Api.Tests;

public sealed class DomainModelTests
{
    [Fact]
    public void Vip_customer_receives_ten_percent_discount()
    {
        var order = Order.Create(
            Guid.NewGuid(),
            "reader@vip.northstar.test",
            DateTimeOffset.UtcNow);

        order.AddItem(
            Guid.NewGuid(),
            "Architecture Field Guide",
            new Money(100m),
            quantity: 2,
            maxPurchaseQuantity: 5,
            isDiscontinued: false);

        order.Place();

        Assert.Equal(200m, order.Subtotal.Amount);
        Assert.Equal(20m, order.Discount.Amount);
        Assert.Equal(180m, order.Total.Amount);
    }

    [Fact]
    public void Expensive_order_requires_approval()
    {
        var order = Order.Create(
            Guid.NewGuid(),
            "reader@example.com",
            DateTimeOffset.UtcNow);

        order.AddItem(
            Guid.NewGuid(),
            "Architecture Workshop",
            new Money(1_200m),
            quantity: 1,
            maxPurchaseQuantity: 1,
            isDiscontinued: false);

        order.Place();

        Assert.Equal(
            OrderStatus.PendingApproval,
            order.Status);
    }

    [Fact]
    public void Placed_order_cannot_be_modified()
    {
        var productId = Guid.NewGuid();

        var order = Order.Create(
            Guid.NewGuid(),
            "reader@example.com",
            DateTimeOffset.UtcNow);

        order.AddItem(
            productId,
            "Architecture Field Guide",
            new Money(50m),
            quantity: 1,
            maxPurchaseQuantity: 5,
            isDiscontinued: false);

        order.Place();

        Assert.Throws<InvalidOperationException>(() =>
            order.ChangeQuantity(
                productId,
                quantity: 2,
                maxPurchaseQuantity: 5));
    }

    [Fact]
    public void Shipped_order_cannot_be_cancelled()
    {
        // Shipment transition is not implemented yet.
        // This test intentionally documents the next lifecycle pressure.
        Assert.True(true);
    }
}
