using Northstar.Domain.Orders;

namespace Northstar.Api.Tests;

public sealed class DomainEventTests
{
    [Fact]
    public void Placing_order_records_OrderPlaced_fact()
    {
        var order = Order.Create(
            Guid.NewGuid(),
            "reader@example.com",
            DateTimeOffset.UtcNow);

        order.AddItem(
            Guid.NewGuid(),
            "Architecture Field Guide",
            new Money(50m),
            quantity: 1,
            maxPurchaseQuantity: 5,
            isDiscontinued: false);

        order.Place();

        var @event =
            Assert.Single(order.DomainEvents);

        var placed =
            Assert.IsType<OrderPlaced>(@event);

        Assert.Equal(order.Id, placed.OrderId);
        Assert.Equal(order.Total, placed.Total);
    }
}
