using Northstar.Domain.Orders;

namespace Northstar.Api.Tests;

public sealed class CqrsBoundaryTests
{
    [Fact]
    public void Write_model_still_owns_business_rules()
    {
        var order = Order.Create(
            Guid.NewGuid(),
            "reader@vip.northstar.test",
            DateTimeOffset.UtcNow);

        order.AddItem(
            Guid.NewGuid(),
            "Architecture Workshop",
            new Money(1_200m),
            quantity: 1,
            maxPurchaseQuantity: 1,
            isDiscontinued: false);

        order.Place();

        Assert.Equal(
            OrderStatus.PendingApproval,
            order.Status);

        Assert.Equal(
            1_080m,
            order.Total.Amount);
    }

    [Fact]
    public void Read_models_are_behavior_free_data_shapes()
    {
        var readModelType =
            typeof(Northstar.Features.Orders.Queries
                .OperationsOrderListItem);

        var publicMethods = readModelType
            .GetMethods()
            .Where(x =>
                x.DeclaringType == readModelType)
            .Select(x => x.Name)
            .ToArray();

        Assert.DoesNotContain(
            "Place",
            publicMethods);

        Assert.DoesNotContain(
            "Cancel",
            publicMethods);
    }
}
