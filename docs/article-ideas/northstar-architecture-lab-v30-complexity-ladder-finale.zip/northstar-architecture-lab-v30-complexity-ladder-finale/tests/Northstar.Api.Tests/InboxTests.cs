using Northstar.Infrastructure.Messaging;

namespace Northstar.Api.Tests;

public sealed class InboxTests
{
    [Fact]
    public void Inbox_records_message_and_handler_identity()
    {
        var messageId = Guid.NewGuid();

        var inbox = InboxMessage.Processed(
            messageId,
            "FulfillmentConsumer",
            DateTimeOffset.UtcNow);

        Assert.Equal(
            messageId,
            inbox.MessageId);

        Assert.Equal(
            "FulfillmentConsumer",
            inbox.Handler);
    }
}
