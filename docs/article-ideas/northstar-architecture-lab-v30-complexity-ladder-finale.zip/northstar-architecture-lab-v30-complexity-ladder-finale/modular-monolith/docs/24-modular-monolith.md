---
title: "Lab 24: Moving Down the Complexity Ladder"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v25-modular-monolith"
status: "draft"
---

# Lab 24: Moving Down the Complexity Ladder

Northstar just did something architecture diagrams rarely celebrate.

It became simpler.

## What We Removed

For Inventory and Fulfillment we removed:

```text
separate process
RabbitMQ hop
Inbox
Outbox
dead-letter topology
cross-process tracing
eventual consistency
independent deployment
```

That is a lot of machinery.

## What We Kept

We kept:

```text
Inventory module
Fulfillment module
public contracts
private implementation
data ownership
dependency rules
tests
```

That distinction is the entire lesson.

## A Module Is Still a Boundary

Ordering depends on:

```csharp
IInventoryModule
```

It does not depend on:

```text
InventoryDbContext
InventoryReservation entity
Inventory tables
```

The deployment boundary disappeared.

The ownership boundary did not.

## Why Payment Stayed External

Payment still represents a boundary with stronger forces:

```text
external provider
different failure semantics
security/compliance
network latency
independent availability
```

That is enough to justify keeping the port remote.

## Local Transactions Are Valuable

Once two capabilities share a process/database boundary, some workflows may regain local transactional options.

That can eliminate entire classes of compensation and delivery problems.

Do not throw away that capability merely because distributed patterns are interesting.

## Architecture Tests

The lab includes tests that assert implementation types remain internal.

A folder naming convention is not enough.

Boundaries should be enforceable.

## The Big Lesson

The Complexity Ladder is not one-way.

```text
microservice
   |
   v
module
```

can be an architectural improvement when independent deployment no longer justifies the distributed tax.

Simplification is not failure.

It is one of the clearest signs that architecture is being driven by forces instead of fashion.
