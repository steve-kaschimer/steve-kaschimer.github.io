# Exercise 3 — Design Your Own Northstar

Start with this constraint:

```text
one ASP.NET Core application
one relational database
one deployment unit
```

Now choose a business domain.

Add architecture only when you can write a failing scenario that the current design cannot responsibly handle.

Keep a decision log:

| Step | New Pressure | Decision | Alternatives Rejected | Complexity Added | Removal Trigger |
|---|---|---|---|---|---|

The last column is important.

Before adopting a pattern, state the condition under which you would remove it.

That turns architecture from accumulation into lifecycle management.
