# Exercise 2 — Remove a Pattern

Choose one:

```text
Saga
Cache-Aside
RabbitMQ
Circuit Breaker
Feature Flag
Sidecar
```

Assume the force that justified it has disappeared.

Answer:

1. What code can be deleted?
2. What infrastructure can be deleted?
3. What operational procedures disappear?
4. What failure modes disappear?
5. What capabilities are lost?
6. Which boundary must remain even after the pattern is removed?

The objective is to practice **architectural subtraction**.
