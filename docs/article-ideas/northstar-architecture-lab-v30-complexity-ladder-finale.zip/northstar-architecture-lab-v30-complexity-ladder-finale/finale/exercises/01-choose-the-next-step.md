# Exercise 1 — Choose the Next Step

For each scenario, do **not** start by naming a pattern.

Write:

```text
Pressure:
Failure mode:
Simplest acceptable response:
Complexity introduced:
How we will know it worked:
```

## Scenario A

Checkout traffic spikes 20x for fifteen minutes every Friday.

## Scenario B

The Payment provider occasionally takes 25 seconds to respond.

## Scenario C

Operations refreshes the same dashboard every second.

## Scenario D

Inventory and Ordering are owned by one team, always deploy together, and almost never scale independently.

## Scenario E

A legacy Warehouse API cannot be retired this year, but one endpoint is causing most incidents.

After answering, compare your reasoning with the Northstar stages—not just the pattern names.
