# Northstar v30 — Architecture Complexity Ladder Finale

This is the retrospective lab.

Northstar has spent the entire series doing two things:

1. adding complexity when pressure justified it;
2. removing complexity when the forces changed.

The final exercise is not to add another pattern.

It is to learn to make that decision deliberately.

## Start Here

Read:

```text
docs/29-architecture-complexity-ladder.md
```

Then work through:

```text
exercises/01-choose-the-next-step.md
exercises/02-remove-a-pattern.md
exercises/03-design-your-own-northstar.md
```

## The Thesis

```text
Architecture is not a pattern inventory.

Architecture is a sequence of decisions
made in response to forces.
```

The best architecture is not the one with the most patterns.

It is the least complicated architecture that responsibly handles the forces the system actually faces.
