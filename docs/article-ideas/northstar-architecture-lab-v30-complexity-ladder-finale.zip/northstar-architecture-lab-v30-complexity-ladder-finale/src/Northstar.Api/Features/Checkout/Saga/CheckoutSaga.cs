namespace Northstar.Features.Checkout.Saga;

public sealed class CheckoutSaga
{
    private CheckoutSaga() { }

    public CheckoutSaga(
        Guid id,
        Guid orderId,
        DateTimeOffset startedAt)
    {
        Id = id;
        OrderId = orderId;
        StartedAt = startedAt;
        Status = CheckoutSagaStatus.Started;
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public Guid? InventoryReservationId { get; private set; }
    public Guid? PaymentAuthorizationId { get; private set; }
    public CheckoutSagaStatus Status { get; private set; }
    public DateTimeOffset StartedAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }

    public void MarkInventoryReserved(Guid reservationId)
    {
        InventoryReservationId = reservationId;
        Status = CheckoutSagaStatus.InventoryReserved;
    }

    public void MarkPaymentAuthorized(Guid paymentId)
    {
        PaymentAuthorizationId = paymentId;
        Status = CheckoutSagaStatus.PaymentAuthorized;
    }

    public void MarkPaymentDeclined(Guid paymentId)
    {
        PaymentAuthorizationId = paymentId;
        Status = CheckoutSagaStatus.PaymentDeclined;
    }

    public void MarkCompensated(DateTimeOffset completedAt)
    {
        Status = CheckoutSagaStatus.Compensated;
        CompletedAt = completedAt;
    }

    public void MarkCompleted(DateTimeOffset completedAt)
    {
        Status = CheckoutSagaStatus.Completed;
        CompletedAt = completedAt;
    }
}

public enum CheckoutSagaStatus
{
    Started = 0,
    InventoryReserved = 1,
    PaymentAuthorized = 2,
    PaymentDeclined = 3,
    Compensated = 4,
    Completed = 5
}
