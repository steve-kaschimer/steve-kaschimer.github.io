namespace Northstar.Features.Checkout;

public static class CheckoutEndpoints
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapPost(
            "/orders/{orderId:guid}/checkout",
            async (
                Guid orderId,
                CheckoutCoordinator checkout,
                CancellationToken cancellationToken) =>
                await checkout.ExecuteAsync(
                    orderId,
                    cancellationToken));
    }
}
