using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Features.Checkout.Saga;
using Northstar.Features.Inventory;
using Northstar.Features.Payments;

namespace Northstar.Features.Checkout;

public sealed class CheckoutCoordinator(
    NorthstarDbContext db,
    InventoryService inventory,
    PaymentService payments,
    TimeProvider timeProvider)
{
    public async Task<IResult> ExecuteAsync(
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var order = await db.Orders
            .AsNoTracking()
            .SingleOrDefaultAsync(
                x => x.Id == orderId,
                cancellationToken);

        if (order is null)
            return Results.NotFound();

        var saga = new CheckoutSaga(
            Guid.NewGuid(),
            order.Id,
            timeProvider.GetUtcNow());

        db.CheckoutSagas.Add(saga);
        await db.SaveChangesAsync(cancellationToken);

        var reservation =
            await inventory.ReserveAsync(
                order.Id,
                cancellationToken);

        saga.MarkInventoryReserved(
            reservation.Id);

        await db.SaveChangesAsync(
            cancellationToken);

        var payment =
            await payments.AuthorizeAsync(
                order.Id,
                order.Total.Amount,
                cancellationToken);

        if (payment.Status == "Declined")
        {
            saga.MarkPaymentDeclined(
                payment.Id);

            await db.SaveChangesAsync(
                cancellationToken);

            await inventory.ReleaseAsync(
                reservation.Id,
                cancellationToken);

            saga.MarkCompensated(
                timeProvider.GetUtcNow());

            await db.SaveChangesAsync(
                cancellationToken);

            return Results.Conflict(new
            {
                sagaId = saga.Id,
                status = saga.Status.ToString(),
                message = "Payment declined; inventory was released."
            });
        }

        saga.MarkPaymentAuthorized(
            payment.Id);

        saga.MarkCompleted(
            timeProvider.GetUtcNow());

        await db.SaveChangesAsync(
            cancellationToken);

        return Results.Ok(new
        {
            sagaId = saga.Id,
            orderId = saga.OrderId,
            reservationId = saga.InventoryReservationId,
            paymentId = saga.PaymentAuthorizationId,
            status = saga.Status.ToString()
        });
    }
}
