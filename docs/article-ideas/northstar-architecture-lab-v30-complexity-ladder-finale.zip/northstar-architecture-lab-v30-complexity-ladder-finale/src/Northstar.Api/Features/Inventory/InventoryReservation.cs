namespace Northstar.Features.Inventory;

public sealed class InventoryReservation
{
    private InventoryReservation() { }

    public InventoryReservation(
        Guid id,
        Guid orderId,
        DateTimeOffset createdAt)
    {
        Id = id;
        OrderId = orderId;
        CreatedAt = createdAt;
        Status = "Reserved";
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public string Status { get; private set; } = "";
    public DateTimeOffset CreatedAt { get; private set; }

    public void Release()
        => Status = "Released";
}
