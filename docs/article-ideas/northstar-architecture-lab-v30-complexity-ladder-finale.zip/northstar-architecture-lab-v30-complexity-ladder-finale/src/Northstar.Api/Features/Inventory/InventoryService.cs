using Northstar.Data;

namespace Northstar.Features.Inventory;

public sealed class InventoryService(
    NorthstarDbContext db,
    TimeProvider timeProvider)
{
    public async Task<InventoryReservation> ReserveAsync(
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var reservation = new InventoryReservation(
            Guid.NewGuid(),
            orderId,
            timeProvider.GetUtcNow());

        db.InventoryReservations.Add(reservation);

        await db.SaveChangesAsync(cancellationToken);

        return reservation;
    }

    public async Task ReleaseAsync(
        Guid reservationId,
        CancellationToken cancellationToken)
    {
        var reservation =
            await db.InventoryReservations.FindAsync(
                [reservationId],
                cancellationToken);

        if (reservation is null)
            return;

        reservation.Release();

        await db.SaveChangesAsync(cancellationToken);
    }
}
