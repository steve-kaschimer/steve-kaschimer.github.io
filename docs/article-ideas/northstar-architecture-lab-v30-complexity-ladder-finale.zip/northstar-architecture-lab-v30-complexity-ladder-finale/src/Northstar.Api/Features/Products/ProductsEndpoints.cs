using Microsoft.EntityFrameworkCore;
using Northstar.Data;

namespace Northstar.Features.Products;

public static class ProductsEndpoints
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapPost("/products", async (
            CreateProductRequest request,
            NorthstarDbContext db,
            CancellationToken cancellationToken) =>
        {
            if (string.IsNullOrWhiteSpace(request.Sku) ||
                string.IsNullOrWhiteSpace(request.Name) ||
                request.Price <= 0 ||
                request.MaxPurchaseQuantity <= 0)
            {
                return Results.BadRequest();
            }

            var product = new Product(
                Guid.NewGuid(),
                request.Sku.Trim(),
                request.Name.Trim(),
                request.Price,
                request.MaxPurchaseQuantity);

            db.Products.Add(product);
            await db.SaveChangesAsync(cancellationToken);

            return Results.Created(
                $"/products/{product.Id}",
                ProductResponse.From(product));
        });

        app.MapGet("/products", async (
            NorthstarDbContext db,
            CancellationToken cancellationToken) =>
        {
            var products = await db.Products
                .AsNoTracking()
                .OrderBy(x => x.Name)
                .Select(x => new ProductResponse(
                    x.Id, x.Sku, x.Name, x.Price,
                    x.IsDiscontinued, x.MaxPurchaseQuantity))
                .ToListAsync(cancellationToken);

            return Results.Ok(products);
        });
    }
}

public sealed record CreateProductRequest(
    string Sku,
    string Name,
    decimal Price,
    int MaxPurchaseQuantity = 10);

public sealed record ProductResponse(
    Guid Id,
    string Sku,
    string Name,
    decimal Price,
    bool IsDiscontinued,
    int MaxPurchaseQuantity)
{
    public static ProductResponse From(Product p) =>
        new(
            p.Id, p.Sku, p.Name, p.Price,
            p.IsDiscontinued, p.MaxPurchaseQuantity);
}
