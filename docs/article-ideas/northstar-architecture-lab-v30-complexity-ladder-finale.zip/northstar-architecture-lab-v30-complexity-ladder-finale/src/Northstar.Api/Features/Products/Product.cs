namespace Northstar.Features.Products;

public sealed class Product
{
    private Product() { }

    public Product(
        Guid id,
        string sku,
        string name,
        decimal price,
        int maxPurchaseQuantity = 10)
    {
        Id = id;
        Sku = sku;
        Name = name;
        Price = price;
        MaxPurchaseQuantity = maxPurchaseQuantity;
    }

    public Guid Id { get; private set; }
    public string Sku { get; private set; } = "";
    public string Name { get; private set; } = "";
    public decimal Price { get; private set; }
    public bool IsDiscontinued { get; private set; }
    public int MaxPurchaseQuantity { get; private set; }
}
