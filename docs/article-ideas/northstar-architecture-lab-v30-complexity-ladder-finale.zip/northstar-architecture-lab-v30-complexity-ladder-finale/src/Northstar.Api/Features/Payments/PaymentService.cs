using Northstar.Data;

namespace Northstar.Features.Payments;

public sealed class PaymentService(
    NorthstarDbContext db,
    IConfiguration configuration,
    TimeProvider timeProvider)
{
    public async Task<PaymentAuthorization> AuthorizeAsync(
        Guid orderId,
        decimal amount,
        CancellationToken cancellationToken)
    {
        var decline =
            configuration.GetValue<bool>(
                "Northstar:DeclinePayments");

        var authorization =
            new PaymentAuthorization(
                Guid.NewGuid(),
                orderId,
                amount,
                decline ? "Declined" : "Authorized",
                timeProvider.GetUtcNow());

        db.PaymentAuthorizations.Add(authorization);

        await db.SaveChangesAsync(cancellationToken);

        return authorization;
    }
}
