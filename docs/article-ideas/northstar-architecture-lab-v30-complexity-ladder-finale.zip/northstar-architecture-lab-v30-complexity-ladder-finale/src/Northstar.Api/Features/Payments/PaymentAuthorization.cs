namespace Northstar.Features.Payments;

public sealed class PaymentAuthorization
{
    private PaymentAuthorization() { }

    public PaymentAuthorization(
        Guid id,
        Guid orderId,
        decimal amount,
        string status,
        DateTimeOffset createdAt)
    {
        Id = id;
        OrderId = orderId;
        Amount = amount;
        Status = status;
        CreatedAt = createdAt;
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public decimal Amount { get; private set; }
    public string Status { get; private set; } = "";
    public DateTimeOffset CreatedAt { get; private set; }
}
