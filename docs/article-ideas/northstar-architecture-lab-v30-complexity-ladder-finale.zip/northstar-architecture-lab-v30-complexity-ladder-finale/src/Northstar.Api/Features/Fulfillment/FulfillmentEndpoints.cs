using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Infrastructure.Messaging;

namespace Northstar.Features.Fulfillment;

public static class FulfillmentEndpoints
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapPost(
            "/lab/fulfillment/deliver",
            async (
                OrderPlacedIntegrationEvent message,
                FulfillmentConsumer consumer,
                CancellationToken cancellationToken) =>
            {
                await consumer.HandleAsync(
                    message,
                    cancellationToken);

                return Results.Accepted();
            });

        app.MapGet(
            "/lab/fulfillment/inbox",
            async (
                NorthstarDbContext db,
                CancellationToken cancellationToken) =>
                Results.Ok(
                    await db.InboxMessages
                        .AsNoTracking()
                        .OrderBy(x => x.ProcessedAt)
                        .ToListAsync(cancellationToken)));

        app.MapGet(
            "/lab/fulfillment/work",
            async (
                NorthstarDbContext db,
                CancellationToken cancellationToken) =>
                Results.Ok(
                    await db.FulfillmentWork
                        .AsNoTracking()
                        .OrderBy(x => x.CreatedAt)
                        .ToListAsync(cancellationToken)));
    }
}
