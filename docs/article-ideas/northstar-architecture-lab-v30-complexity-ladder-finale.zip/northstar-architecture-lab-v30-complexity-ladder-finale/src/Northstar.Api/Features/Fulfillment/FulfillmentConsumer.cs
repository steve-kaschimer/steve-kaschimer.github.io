using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Infrastructure.Messaging;

namespace Northstar.Features.Fulfillment;

public sealed class FulfillmentConsumer(
    NorthstarDbContext db,
    TimeProvider timeProvider)
{
    private const string HandlerName =
        nameof(FulfillmentConsumer);

    public async Task HandleAsync(
        OrderPlacedIntegrationEvent message,
        CancellationToken cancellationToken)
    {
        var alreadyProcessed =
            await db.InboxMessages.AnyAsync(
                x =>
                    x.MessageId == message.EventId &&
                    x.Handler == HandlerName,
                cancellationToken);

        if (alreadyProcessed)
            return;

        await using var transaction =
            await db.Database.BeginTransactionAsync(
                cancellationToken);

        try
        {
            db.InboxMessages.Add(
                InboxMessage.Processed(
                    message.EventId,
                    HandlerName,
                    timeProvider.GetUtcNow()));

            db.FulfillmentWork.Add(
                new FulfillmentWork(
                    Guid.NewGuid(),
                    message.EventId,
                    message.OrderId,
                    timeProvider.GetUtcNow()));

            await db.SaveChangesAsync(
                cancellationToken);

            await transaction.CommitAsync(
                cancellationToken);
        }
        catch (DbUpdateException)
        {
            await transaction.RollbackAsync(
                cancellationToken);

            // Another concurrent delivery may have inserted the
            // same Inbox key first. Re-check before deciding
            // whether this is a duplicate or a real persistence error.
            var duplicate =
                await db.InboxMessages
                    .AsNoTracking()
                    .AnyAsync(
                        x =>
                            x.MessageId == message.EventId &&
                            x.Handler == HandlerName,
                        cancellationToken);

            if (!duplicate)
                throw;
        }
    }
}
