namespace Northstar.Features.Fulfillment;

public sealed class FulfillmentWork
{
    private FulfillmentWork() { }

    public FulfillmentWork(
        Guid id,
        Guid sourceEventId,
        Guid orderId,
        DateTimeOffset createdAt)
    {
        Id = id;
        SourceEventId = sourceEventId;
        OrderId = orderId;
        CreatedAt = createdAt;
    }

    public Guid Id { get; private set; }
    public Guid SourceEventId { get; private set; }
    public Guid OrderId { get; private set; }
    public DateTimeOffset CreatedAt { get; private set; }
}
