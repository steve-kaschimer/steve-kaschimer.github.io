namespace Northstar.Features.Orders.Reactions;

public sealed class ConfirmationService(
    ILogger<ConfirmationService> logger)
{
    public Task SendAsync(
        Guid orderId,
        string customerEmail,
        CancellationToken cancellationToken)
    {
        logger.LogInformation(
            "Confirmation sent for order {OrderId} to {CustomerEmail}",
            orderId,
            customerEmail);

        return Task.CompletedTask;
    }
}

public sealed class LoyaltyService(
    ILogger<LoyaltyService> logger)
{
    public Task AwardAsync(
        Guid orderId,
        string customerEmail,
        decimal total,
        CancellationToken cancellationToken)
    {
        logger.LogInformation(
            "Loyalty updated for order {OrderId} and customer {CustomerEmail} total {Total}",
            orderId,
            customerEmail,
            total);

        return Task.CompletedTask;
    }
}

public sealed class FulfillmentService(
    ILogger<FulfillmentService> logger)
{
    public Task CreateWorkAsync(
        Guid orderId,
        CancellationToken cancellationToken)
    {
        logger.LogInformation(
            "Fulfillment work created for order {OrderId}",
            orderId);

        return Task.CompletedTask;
    }
}

public sealed class AnalyticsService(
    ILogger<AnalyticsService> logger)
{
    public Task RecordOrderPlacedAsync(
        Guid orderId,
        decimal total,
        CancellationToken cancellationToken)
    {
        logger.LogInformation(
            "Analytics recorded OrderPlaced for {OrderId} total {Total}",
            orderId,
            total);

        return Task.CompletedTask;
    }
}
