// Domain model moved to Domain/Orders.
// This file remains intentionally empty to make the evolution obvious in diffs.
