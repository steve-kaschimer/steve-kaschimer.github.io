using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Domain.Orders;

namespace Northstar.Features.Orders.Queries;

public sealed class GetPendingApprovalOrders(
    NorthstarDbContext db)
{
    public Task<List<PendingApprovalOrderResponse>>
        ExecuteAsync(
            CancellationToken cancellationToken)
        => db.Orders
            .AsNoTracking()
            .Where(x =>
                x.Status ==
                OrderStatus.PendingApproval)
            .OrderByDescending(x => x.Total.Amount)
            .Select(x =>
                new PendingApprovalOrderResponse(
                    x.Id,
                    x.CustomerEmail,
                    x.Total.Amount,
                    x.Items.Sum(i => i.Quantity),
                    x.CreatedAt))
            .ToListAsync(cancellationToken);
}
