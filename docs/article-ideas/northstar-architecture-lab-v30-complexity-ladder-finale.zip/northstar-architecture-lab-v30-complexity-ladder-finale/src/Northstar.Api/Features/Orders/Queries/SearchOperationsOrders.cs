using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Domain.Orders;

namespace Northstar.Features.Orders.Queries;

public sealed class SearchOperationsOrders(
    NorthstarDbContext db)
{
    public async Task<List<OperationsOrderListItem>>
        ExecuteAsync(
            string? status,
            int page,
            CancellationToken cancellationToken)
    {
        page = page <= 0 ? 1 : page;

        var query = db.Orders
            .AsNoTracking()
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(status) &&
            Enum.TryParse<OrderStatus>(
                status,
                ignoreCase: true,
                out var parsedStatus))
        {
            query = query.Where(
                x => x.Status == parsedStatus);
        }

        return await query
            .OrderByDescending(x => x.CreatedAt)
            .Skip((page - 1) * 25)
            .Take(25)
            .Select(x =>
                new OperationsOrderListItem(
                    x.Id,
                    x.CustomerEmail,
                    x.Status.ToString(),
                    x.Total.Amount,
                    x.Items.Count,
                    x.CreatedAt))
            .ToListAsync(cancellationToken);
    }
}
