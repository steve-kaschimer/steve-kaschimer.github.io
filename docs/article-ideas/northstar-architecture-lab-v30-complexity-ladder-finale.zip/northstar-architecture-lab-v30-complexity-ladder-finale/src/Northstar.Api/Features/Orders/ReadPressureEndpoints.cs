using Northstar.Features.Orders.Queries;

namespace Northstar.Features.Orders;

public static class ReadPressureEndpoints
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapGet(
            "/operations/orders/pending-approval",
            async (
                GetPendingApprovalOrders query,
                CancellationToken cancellationToken) =>
                Results.Ok(
                    await query.ExecuteAsync(
                        cancellationToken)));

        app.MapGet(
            "/customers/{email}/orders",
            async (
                string email,
                GetCustomerOrderHistory query,
                CancellationToken cancellationToken) =>
                Results.Ok(
                    await query.ExecuteAsync(
                        email,
                        cancellationToken)));

        app.MapGet(
            "/operations/orders",
            async (
                string? status,
                int page,
                SearchOperationsOrders query,
                CancellationToken cancellationToken) =>
                Results.Ok(
                    await query.ExecuteAsync(
                        status,
                        page,
                        cancellationToken)));
    }
}
