using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Features.Orders;

namespace Northstar.Features.Orders.Commands;

public static class ChangeOrderQuantity
{
    public static async Task<IResult> HandleAsync(
        Guid orderId,
        Guid productId,
        ChangeQuantityRequest request,
        NorthstarDbContext db,
        CancellationToken cancellationToken)
    {
        var order = await db.Orders
            .Include("_items")
            .SingleOrDefaultAsync(
                x => x.Id == orderId,
                cancellationToken);

        if (order is null)
            return Results.NotFound();

        var product = await db.Products
            .SingleOrDefaultAsync(
                x => x.Id == productId,
                cancellationToken);

        if (product is null)
            return Results.NotFound();

        try
        {
            order.ChangeQuantity(
                productId,
                request.Quantity,
                product.MaxPurchaseQuantity);

            await db.SaveChangesAsync(
                cancellationToken);

            return Results.Ok(
                OrderResponse.From(order));
        }
        catch (InvalidOperationException exception)
        {
            return Results.Conflict(
                exception.Message);
        }
    }
}

public sealed record ChangeQuantityRequest(int Quantity);
