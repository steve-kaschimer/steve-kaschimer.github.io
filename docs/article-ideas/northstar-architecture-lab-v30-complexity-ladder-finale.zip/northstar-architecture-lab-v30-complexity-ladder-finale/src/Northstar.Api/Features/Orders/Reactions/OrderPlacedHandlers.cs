using Northstar.Application.DomainEvents;
using Northstar.Domain.Orders;
using Northstar.Infrastructure.Messaging;

namespace Northstar.Features.Orders.Reactions;

public sealed class SendConfirmationWhenOrderPlaced(
    ConfirmationService confirmation)
    : IDomainEventHandler<OrderPlaced>
{
    public Task HandleAsync(
        OrderPlaced domainEvent,
        CancellationToken cancellationToken)
        => confirmation.SendAsync(
            domainEvent.OrderId,
            domainEvent.CustomerEmail,
            cancellationToken);
}

public sealed class AwardLoyaltyWhenOrderPlaced(
    LoyaltyService loyalty)
    : IDomainEventHandler<OrderPlaced>
{
    public Task HandleAsync(
        OrderPlaced domainEvent,
        CancellationToken cancellationToken)
        => loyalty.AwardAsync(
            domainEvent.OrderId,
            domainEvent.CustomerEmail,
            domainEvent.Total.Amount,
            cancellationToken);
}

public sealed class CreateFulfillmentWhenOrderPlaced(
    FulfillmentService fulfillment)
    : IDomainEventHandler<OrderPlaced>
{
    public Task HandleAsync(
        OrderPlaced domainEvent,
        CancellationToken cancellationToken)
        => fulfillment.CreateWorkAsync(
            domainEvent.OrderId,
            cancellationToken);
}

public sealed class RecordAnalyticsWhenOrderPlaced(
    AnalyticsService analytics)
    : IDomainEventHandler<OrderPlaced>
{
    public Task HandleAsync(
        OrderPlaced domainEvent,
        CancellationToken cancellationToken)
        => analytics.RecordOrderPlacedAsync(
            domainEvent.OrderId,
            domainEvent.Total.Amount,
            cancellationToken);
}




public sealed class StoreOrderPlacedInOutbox(
    Northstar.Data.NorthstarDbContext db)
    : IDomainEventHandler<OrderPlaced>
{
    public Task HandleAsync(
        OrderPlaced domainEvent,
        CancellationToken cancellationToken)
    {
        var integrationEvent =
            new OrderPlacedIntegrationEvent(
                Guid.NewGuid(),
                domainEvent.OrderId,
                domainEvent.CustomerEmail,
                domainEvent.Total.Amount,
                domainEvent.OccurredAt);

        var payload =
            System.Text.Json.JsonSerializer.Serialize(
                integrationEvent);

        db.OutboxMessages.Add(
            OutboxMessage.Create(
                integrationEvent.EventId,
                nameof(OrderPlacedIntegrationEvent),
                payload,
                integrationEvent.OccurredAt));

        return Task.CompletedTask;
    }
}
