using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Features.Orders;

namespace Northstar.Features.Orders.Commands;

public static class CancelOrder
{
    public static async Task<IResult> HandleAsync(
        Guid id,
        NorthstarDbContext db,
        CancellationToken cancellationToken)
    {
        var order = await db.Orders
            .SingleOrDefaultAsync(
                x => x.Id == id,
                cancellationToken);

        if (order is null)
            return Results.NotFound();

        try
        {
            order.Cancel();

            await db.SaveChangesAsync(
                cancellationToken);

            return Results.NoContent();
        }
        catch (InvalidOperationException exception)
        {
            return Results.Conflict(
                exception.Message);
        }
    }
}
