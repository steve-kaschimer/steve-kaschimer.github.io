using Microsoft.EntityFrameworkCore;
using Northstar.Data;

namespace Northstar.Features.Orders.Queries;

public sealed class GetCustomerOrderHistory(
    NorthstarDbContext db)
{
    public Task<List<CustomerOrderHistoryItem>>
        ExecuteAsync(
            string email,
            CancellationToken cancellationToken)
        => db.Orders
            .AsNoTracking()
            .Where(x => x.CustomerEmail == email)
            .OrderByDescending(x => x.CreatedAt)
            .Select(x =>
                new CustomerOrderHistoryItem(
                    x.Id,
                    x.Status.ToString(),
                    x.Total.Amount,
                    x.Items.Count,
                    x.CreatedAt))
            .ToListAsync(cancellationToken);
}
