using Northstar.Features.Orders.Commands;
using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Domain.Orders;

namespace Northstar.Features.Orders;

public static class OrdersEndpoints
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapPost("/orders", PlaceOrder.HandleAsync);
        app.MapPost("/orders/{id:guid}/cancel", CancelOrder.HandleAsync);
        app.MapPut(
            "/orders/{orderId:guid}/items/{productId:guid}",
            ChangeOrderQuantity.HandleAsync);

        app.MapGet("/orders/{id:guid}", async (
            Guid id,
            NorthstarDbContext db,
            CancellationToken cancellationToken) =>
        {
            var order = await db.Orders
                .AsNoTracking()
                .Include("_items")
                .SingleOrDefaultAsync(
                    x => x.Id == id,
                    cancellationToken);

            return order is null
                ? Results.NotFound()
                : Results.Ok(
                    OrderResponse.From(order));
        });
    }
}

public sealed record PlaceOrderRequest(
    string CustomerEmail,
    IReadOnlyList<PlaceOrderItemRequest> Items);

public sealed record PlaceOrderItemRequest(
    Guid ProductId,
    int Quantity);

public sealed record OrderResponse(
    Guid Id,
    string CustomerEmail,
    string Status,
    decimal Subtotal,
    decimal Discount,
    decimal Total,
    DateTimeOffset CreatedAt,
    IReadOnlyList<OrderItemResponse> Items)
{
    public static OrderResponse From(Order order) =>
        new(
            order.Id,
            order.CustomerEmail,
            order.Status.ToString(),
            order.Subtotal.Amount,
            order.Discount.Amount,
            order.Total.Amount,
            order.CreatedAt,
            order.Items.Select(x =>
                new OrderItemResponse(
                    x.ProductId,
                    x.ProductName,
                    x.Quantity,
                    x.UnitPrice.Amount))
                .ToList());
}

public sealed record OrderItemResponse(
    Guid ProductId,
    string ProductName,
    int Quantity,
    decimal UnitPrice);
