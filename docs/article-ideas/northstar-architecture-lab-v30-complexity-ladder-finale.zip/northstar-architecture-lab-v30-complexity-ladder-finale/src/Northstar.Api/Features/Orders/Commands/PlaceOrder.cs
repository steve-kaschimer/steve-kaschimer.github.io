using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Domain.Orders;
using Northstar.Features.Orders;
using Northstar.Application.DomainEvents;

namespace Northstar.Features.Orders.Commands;

public static class PlaceOrder
{
    public static async Task<IResult> HandleAsync(
        PlaceOrderRequest request,
        NorthstarDbContext db,
        TimeProvider timeProvider,
        DomainEventDispatcher domainEvents,
        CancellationToken cancellationToken)
    {
        var productIds = request.Items
            .Select(x => x.ProductId)
            .Distinct()
            .ToArray();

        var products = await db.Products
            .Where(x => productIds.Contains(x.Id))
            .ToDictionaryAsync(
                x => x.Id,
                cancellationToken);

        if (products.Count != productIds.Length)
            return Results.BadRequest(
                "One or more products do not exist.");

        try
        {
            var order = Order.Create(
                Guid.NewGuid(),
                request.CustomerEmail,
                timeProvider.GetUtcNow());

            foreach (var requestedItem in request.Items)
            {
                var product = products[requestedItem.ProductId];

                order.AddItem(
                    product.Id,
                    product.Name,
                    new Money(product.Price),
                    requestedItem.Quantity,
                    product.MaxPurchaseQuantity,
                    product.IsDiscontinued);
            }

            order.Place();

            db.Orders.Add(order);

            var events = order.DomainEvents.ToArray();

            // Local handlers may add Outbox rows to the same DbContext.
            await domainEvents.DispatchAsync(
                events,
                cancellationToken);

            await db.SaveChangesAsync(
                cancellationToken);

            order.ClearDomainEvents();

            return Results.Created(
                $"/orders/{order.Id}",
                OrderResponse.From(order));
        }
        catch (InvalidOperationException exception)
        {
            return Results.BadRequest(
                exception.Message);
        }
    }
}
