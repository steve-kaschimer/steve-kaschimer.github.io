namespace Northstar.Features.Orders.Queries;

public sealed record PendingApprovalOrderResponse(
    Guid OrderId,
    string CustomerEmail,
    decimal Total,
    int Units,
    DateTimeOffset CreatedAt);

public sealed record CustomerOrderHistoryItem(
    Guid OrderId,
    string Status,
    decimal Total,
    int LineCount,
    DateTimeOffset CreatedAt);

public sealed record OperationsOrderListItem(
    Guid OrderId,
    string CustomerEmail,
    string Status,
    decimal Total,
    int LineCount,
    DateTimeOffset CreatedAt);
