namespace Northstar.Infrastructure.Messaging;

public sealed record OrderPlacedIntegrationEvent(
    Guid EventId,
    Guid OrderId,
    string CustomerEmail,
    decimal Total,
    DateTimeOffset OccurredAt)
    : IIntegrationEvent;
