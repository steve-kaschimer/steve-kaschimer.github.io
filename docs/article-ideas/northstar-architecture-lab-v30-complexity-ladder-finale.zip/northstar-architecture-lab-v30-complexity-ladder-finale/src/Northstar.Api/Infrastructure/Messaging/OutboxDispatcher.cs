using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Northstar.Data;

namespace Northstar.Infrastructure.Messaging;

public sealed class OutboxDispatcher(
    IServiceScopeFactory scopeFactory,
    ILogger<OutboxDispatcher> logger)
    : BackgroundService
{
    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await DispatchBatchAsync(stoppingToken);
            }
            catch (Exception exception)
            {
                logger.LogError(
                    exception,
                    "Outbox dispatch cycle failed.");
            }

            await Task.Delay(
                TimeSpan.FromSeconds(2),
                stoppingToken);
        }
    }

    private async Task DispatchBatchAsync(
        CancellationToken cancellationToken)
    {
        await using var scope =
            scopeFactory.CreateAsyncScope();

        var db =
            scope.ServiceProvider
                .GetRequiredService<NorthstarDbContext>();

        var publisher =
            scope.ServiceProvider
                .GetRequiredService<IIntegrationEventPublisher>();

        var messages = await db.OutboxMessages
            .Where(x => x.PublishedAt == null)
            .OrderBy(x => x.OccurredAt)
            .Take(50)
            .ToListAsync(cancellationToken);

        foreach (var message in messages)
        {
            try
            {
                IIntegrationEvent integrationEvent =
                    message.Type switch
                    {
                        nameof(OrderPlacedIntegrationEvent) =>
                            JsonSerializer.Deserialize<OrderPlacedIntegrationEvent>(
                                message.Payload)
                            ?? throw new InvalidOperationException(
                                "Could not deserialize outbox message."),

                        _ => throw new InvalidOperationException(
                            $"Unknown outbox type '{message.Type}'.")
                    };

                await publisher.PublishAsync(
                    integrationEvent,
                    cancellationToken);

                message.MarkPublished(
                    DateTimeOffset.UtcNow);
            }
            catch (Exception exception)
            {
                message.MarkFailed(
                    exception.Message);

                logger.LogWarning(
                    exception,
                    "Failed to publish Outbox message {MessageId}",
                    message.Id);
            }
        }

        await db.SaveChangesAsync(
            cancellationToken);
    }
}
