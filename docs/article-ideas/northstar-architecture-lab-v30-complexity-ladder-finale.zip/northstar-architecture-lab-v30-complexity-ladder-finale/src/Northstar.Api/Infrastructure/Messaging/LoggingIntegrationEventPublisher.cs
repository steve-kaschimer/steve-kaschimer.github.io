namespace Northstar.Infrastructure.Messaging;

public sealed class LoggingIntegrationEventPublisher(
    ILogger<LoggingIntegrationEventPublisher> logger,
    IConfiguration configuration)
    : IIntegrationEventPublisher
{
    public Task PublishAsync(
        IIntegrationEvent integrationEvent,
        CancellationToken cancellationToken)
    {
        var shouldFail =
            configuration.GetValue<bool>(
                "Northstar:FailPublish");

        if (shouldFail)
        {
            throw new InvalidOperationException(
                "Simulated broker outage.");
        }

        logger.LogInformation(
            "Published integration event {EventType} {EventId}",
            integrationEvent.GetType().Name,
            integrationEvent.EventId);

        return Task.CompletedTask;
    }
}
