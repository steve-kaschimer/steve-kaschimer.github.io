namespace Northstar.Infrastructure.Messaging;

public sealed class InboxMessage
{
    private InboxMessage() { }

    public Guid MessageId { get; private set; }
    public string Handler { get; private set; } = "";
    public DateTimeOffset ProcessedAt { get; private set; }

    public static InboxMessage Processed(
        Guid messageId,
        string handler,
        DateTimeOffset processedAt)
        => new()
        {
            MessageId = messageId,
            Handler = handler,
            ProcessedAt = processedAt
        };
}
