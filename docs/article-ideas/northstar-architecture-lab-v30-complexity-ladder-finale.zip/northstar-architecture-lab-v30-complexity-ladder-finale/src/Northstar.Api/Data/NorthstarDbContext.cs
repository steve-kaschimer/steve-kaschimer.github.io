using Microsoft.EntityFrameworkCore;
using Northstar.Domain.Orders;
using Northstar.Features.Products;
using Northstar.Features.Fulfillment;
using Northstar.Features.Inventory;
using Northstar.Features.Payments;
using Northstar.Features.Checkout.Saga;
using Northstar.Infrastructure.Messaging;

namespace Northstar.Data;

public sealed class NorthstarDbContext(
    DbContextOptions<NorthstarDbContext> options)
    : DbContext(options)
{
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<OutboxMessage> OutboxMessages => Set<OutboxMessage>();
    public DbSet<FulfillmentWork> FulfillmentWork => Set<FulfillmentWork>();
    public DbSet<InboxMessage> InboxMessages => Set<InboxMessage>();
    public DbSet<InventoryReservation> InventoryReservations => Set<InventoryReservation>();
    public DbSet<PaymentAuthorization> PaymentAuthorizations => Set<PaymentAuthorization>();
    public DbSet<CheckoutSaga> CheckoutSagas => Set<CheckoutSaga>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OutboxMessage>(outbox =>
        {
            outbox.HasKey(x => x.Id);
            outbox.HasIndex(x => new { x.PublishedAt, x.OccurredAt });
        });

        modelBuilder.Entity<InboxMessage>(inbox =>
        {
            inbox.HasKey(x => new { x.MessageId, x.Handler });
        });

        modelBuilder.Entity<Product>()
            .HasIndex(x => x.Sku)
            .IsUnique();

        modelBuilder.Entity<Order>(order =>
        {
            order.Property(x => x.Status)
                .HasConversion<string>();

            order.OwnsOne(x => x.Subtotal);
            order.OwnsOne(x => x.Discount);
            order.OwnsOne(x => x.Total);

            order.HasMany(typeof(OrderItem), "_items")
                .WithOne()
                .HasForeignKey(nameof(OrderItem.OrderId));
        });

        modelBuilder.Entity<OrderItem>(item =>
        {
            item.OwnsOne(x => x.UnitPrice);
        });
    }
}
