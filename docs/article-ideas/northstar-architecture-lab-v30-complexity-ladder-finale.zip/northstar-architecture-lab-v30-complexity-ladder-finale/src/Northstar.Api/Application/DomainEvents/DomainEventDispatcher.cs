using Northstar.Domain.Common;

namespace Northstar.Application.DomainEvents;

public sealed class DomainEventDispatcher(
    IServiceProvider services)
{
    public async Task DispatchAsync(
        IEnumerable<IDomainEvent> events,
        CancellationToken cancellationToken)
    {
        foreach (var domainEvent in events)
        {
            var handlerType =
                typeof(IDomainEventHandler<>)
                    .MakeGenericType(
                        domainEvent.GetType());

            var handlers =
                services.GetServices(handlerType);

            foreach (dynamic handler in handlers)
            {
                await handler.HandleAsync(
                    (dynamic)domainEvent,
                    cancellationToken);
            }
        }
    }
}
