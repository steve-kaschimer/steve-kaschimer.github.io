using Microsoft.EntityFrameworkCore;
using Northstar.Data;
using Northstar.Features.Orders;
using Northstar.Features.Orders.Queries;
using Northstar.Features.Orders.Reactions;
using Northstar.Application.DomainEvents;
using Northstar.Domain.Orders;
using Northstar.Infrastructure.Messaging;
using Northstar.Features.Fulfillment;
using Northstar.Features.Inventory;
using Northstar.Features.Payments;
using Northstar.Features.Checkout;
using Northstar.Features.Products;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<NorthstarDbContext>(options =>
    options.UseSqlite(
        builder.Configuration.GetConnectionString("Northstar")
        ?? "Data Source=northstar.db"));

builder.Services.AddScoped<GetPendingApprovalOrders>();
builder.Services.AddScoped<GetCustomerOrderHistory>();
builder.Services.AddScoped<SearchOperationsOrders>();

builder.Services.AddScoped<ConfirmationService>();
builder.Services.AddScoped<LoyaltyService>();
builder.Services.AddScoped<FulfillmentService>();
builder.Services.AddScoped<AnalyticsService>();

builder.Services.AddScoped<DomainEventDispatcher>();
builder.Services.AddScoped<IDomainEventHandler<OrderPlaced>, SendConfirmationWhenOrderPlaced>();
builder.Services.AddScoped<IDomainEventHandler<OrderPlaced>, AwardLoyaltyWhenOrderPlaced>();
builder.Services.AddScoped<IDomainEventHandler<OrderPlaced>, CreateFulfillmentWhenOrderPlaced>();
builder.Services.AddScoped<IDomainEventHandler<OrderPlaced>, RecordAnalyticsWhenOrderPlaced>();

builder.Services.AddSingleton<IIntegrationEventPublisher, LoggingIntegrationEventPublisher>();
builder.Services.AddHostedService<OutboxDispatcher>();
builder.Services.AddScoped<FulfillmentConsumer>();
builder.Services.AddScoped<InventoryService>();
builder.Services.AddScoped<PaymentService>();
builder.Services.AddScoped<CheckoutCoordinator>();
builder.Services.AddScoped<IDomainEventHandler<OrderPlaced>, StoreOrderPlacedInOutbox>();

var app = builder.Build();

await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<NorthstarDbContext>();
    await db.Database.EnsureCreatedAsync();
}

app.MapGet("/", () => Results.Ok(new
{
    application = "Northstar Commerce",
    stage = "v1-baseline"
}));

ProductsEndpoints.Map(app);
OrdersEndpoints.Map(app);
ReadPressureEndpoints.Map(app);
FulfillmentEndpoints.Map(app);
CheckoutEndpoints.Map(app);

app.Run();

public partial class Program;
