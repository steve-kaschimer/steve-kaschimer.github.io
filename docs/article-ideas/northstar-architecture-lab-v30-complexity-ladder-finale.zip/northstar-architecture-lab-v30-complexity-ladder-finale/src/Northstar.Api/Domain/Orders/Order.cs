using Northstar.Domain.Common;

namespace Northstar.Domain.Orders;

public sealed class Order
{
    private readonly List<OrderItem> _items = [];
    private readonly List<IDomainEvent> _domainEvents = [];

    private Order() { }

    private Order(
        Guid id,
        string customerEmail,
        DateTimeOffset createdAt)
    {
        Id = id;
        CustomerEmail = customerEmail;
        CreatedAt = createdAt;
        Status = OrderStatus.Draft;
    }

    public Guid Id { get; private set; }
    public string CustomerEmail { get; private set; } = "";
    public OrderStatus Status { get; private set; }
    public Money Subtotal { get; private set; }
    public Money Discount { get; private set; }
    public Money Total { get; private set; }
    public DateTimeOffset CreatedAt { get; private set; }

    public IReadOnlyCollection<OrderItem> Items => _items.AsReadOnly();
    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    public static Order Create(
        Guid id,
        string customerEmail,
        DateTimeOffset createdAt)
    {
        if (string.IsNullOrWhiteSpace(customerEmail))
            throw new InvalidOperationException("Customer email is required.");

        return new Order(
            id,
            customerEmail.Trim(),
            createdAt);
    }

    public void AddItem(
        Guid productId,
        string productName,
        Money unitPrice,
        int quantity,
        int maxPurchaseQuantity,
        bool isDiscontinued)
    {
        EnsureDraft();

        if (isDiscontinued)
            throw new InvalidOperationException(
                $"Product '{productName}' is discontinued.");

        if (quantity <= 0 ||
            quantity > maxPurchaseQuantity)
        {
            throw new InvalidOperationException(
                $"Quantity must be between 1 and {maxPurchaseQuantity}.");
        }

        _items.Add(
            new OrderItem(
                Guid.NewGuid(),
                Id,
                productId,
                productName,
                quantity,
                unitPrice));

        Recalculate();
    }

    public void ChangeQuantity(
        Guid productId,
        int quantity,
        int maxPurchaseQuantity)
    {
        EnsureDraft();

        if (quantity <= 0 ||
            quantity > maxPurchaseQuantity)
        {
            throw new InvalidOperationException(
                $"Quantity must be between 1 and {maxPurchaseQuantity}.");
        }

        var item =
            _items.SingleOrDefault(x => x.ProductId == productId)
            ?? throw new InvalidOperationException(
                "Order item not found.");

        item.ChangeQuantity(quantity);

        Recalculate();
    }

    public void Place()
    {
        EnsureDraft();

        if (_items.Count == 0)
            throw new InvalidOperationException(
                "An order must contain at least one item.");

        Recalculate();

        Status = Total.Amount > 1_000m
            ? OrderStatus.PendingApproval
            : OrderStatus.Placed;

        _domainEvents.Add(
            new OrderPlaced(
                Id,
                CustomerEmail,
                Total,
                DateTimeOffset.UtcNow));
    }

    public void Cancel()
    {
        if (Status == OrderStatus.Cancelled)
            throw new InvalidOperationException(
                "Order is already cancelled.");

        if (Status == OrderStatus.Shipped)
            throw new InvalidOperationException(
                "A shipped order cannot be cancelled.");

        Status = OrderStatus.Cancelled;
    }

    private void Recalculate()
    {
        Subtotal = new Money(
            _items.Sum(x => x.UnitPrice.Amount * x.Quantity));

        Discount =
            PricingPolicy.CalculateDiscount(
                CustomerEmail,
                Subtotal);

        Total = Subtotal - Discount;
    }

    public void ClearDomainEvents()
        => _domainEvents.Clear();

    private void EnsureDraft()
    {
        if (Status != OrderStatus.Draft)
            throw new InvalidOperationException(
                "Only draft orders can be modified.");
    }
}

public sealed class OrderItem
{
    private OrderItem() { }

    internal OrderItem(
        Guid id,
        Guid orderId,
        Guid productId,
        string productName,
        int quantity,
        Money unitPrice)
    {
        Id = id;
        OrderId = orderId;
        ProductId = productId;
        ProductName = productName;
        Quantity = quantity;
        UnitPrice = unitPrice;
    }

    public Guid Id { get; private set; }
    public Guid OrderId { get; private set; }
    public Guid ProductId { get; private set; }
    public string ProductName { get; private set; } = "";
    public int Quantity { get; private set; }
    public Money UnitPrice { get; private set; }

    internal void ChangeQuantity(int quantity)
        => Quantity = quantity;
}
