namespace Northstar.Domain.Orders;

public static class PricingPolicy
{
    public static Money CalculateDiscount(
        string customerEmail,
        Money subtotal)
    {
        var isVip =
            customerEmail.EndsWith(
                "@vip.northstar.test",
                StringComparison.OrdinalIgnoreCase);

        return isVip
            ? subtotal * 0.10m
            : Money.Zero;
    }
}
