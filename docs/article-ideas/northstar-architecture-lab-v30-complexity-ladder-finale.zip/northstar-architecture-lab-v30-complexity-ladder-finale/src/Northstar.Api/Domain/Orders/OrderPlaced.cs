using Northstar.Domain.Common;

namespace Northstar.Domain.Orders;

public sealed record OrderPlaced(
    Guid OrderId,
    string CustomerEmail,
    Money Total,
    DateTimeOffset OccurredAt)
    : IDomainEvent;
