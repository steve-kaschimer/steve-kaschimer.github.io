namespace Northstar.Domain.Orders;

public readonly record struct Money(decimal Amount)
{
    public static Money Zero => new(0m);

    public static Money operator +(Money left, Money right) =>
        new(left.Amount + right.Amount);

    public static Money operator -(Money left, Money right) =>
        new(left.Amount - right.Amount);

    public static Money operator *(Money money, decimal multiplier) =>
        new(decimal.Round(money.Amount * multiplier, 2));
}
