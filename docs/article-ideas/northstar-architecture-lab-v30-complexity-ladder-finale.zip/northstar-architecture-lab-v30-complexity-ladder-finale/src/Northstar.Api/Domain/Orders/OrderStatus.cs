namespace Northstar.Domain.Orders;

public enum OrderStatus
{
    Draft = 0,
    PendingApproval = 1,
    Placed = 2,
    Cancelled = 3,
    Shipped = 4
}
