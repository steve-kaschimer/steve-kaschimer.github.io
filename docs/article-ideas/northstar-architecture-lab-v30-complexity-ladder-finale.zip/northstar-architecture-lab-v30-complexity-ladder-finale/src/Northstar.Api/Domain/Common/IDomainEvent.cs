namespace Northstar.Domain.Common;

public interface IDomainEvent;
