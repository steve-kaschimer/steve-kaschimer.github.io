# Northstar Architecture Lab — Stage Map

| Version | Theme |
|---|---|
| v1 | Simple baseline |
| v2–3 | Business rules and Domain Model |
| v4–5 | Read/write pressure and CQRS |
| v6–7 | Domain Events |
| v8–9 | Integration Events and Outbox |
| v10–11 | Duplicate delivery and Inbox |
| v12–14 | Saga and asynchronous distribution |
| v15 | Reliable Saga participants |
| v16–17 | Operational pressure, resilience, observability |
| v18 | Dead-letter recovery |
| v19 | Load and capacity |
| v20–21 | Read pressure and Cache-Aside |
| v22 | Optimistic Concurrency |
| v23 | Progressive delivery and health |
| v24–25 | Modular Monolith and architectural subtraction |
| v26–27 | Strangler Fig modernization |
| v28 | Contract Testing |
| v29 | Sidecar |
| v30 | Architecture Complexity Ladder retrospective |

## One Question Per Stage

For every stage, ask:

```text
What broke or became risky?
Why was the previous design no longer sufficient?
What did the new pattern buy?
What did it cost?
When could we remove it?
```
