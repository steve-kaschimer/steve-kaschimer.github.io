# Northstar v27 — Strangler Fig

The legacy Shipping capability is now behind a routing boundary.

Traffic can be sent to:

```text
LegacyShipping
or
NewFulfillment
```

The legacy response is translated through an Anti-Corruption Layer before it reaches the new model.

Toggle:

```text
Modernization:UseNewFulfillment
```

to switch the status capability.

See:

```text
docs/26-strangler-fig.md
```
