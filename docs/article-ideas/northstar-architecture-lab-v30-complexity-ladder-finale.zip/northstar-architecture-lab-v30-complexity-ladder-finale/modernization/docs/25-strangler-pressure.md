---
title: "Lab 25: Modernization Is a Migration Problem"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v26-legacy-strangler-pressure"
status: "draft"
---

# Lab 25: Modernization Is a Migration Problem

Northstar now has a legacy Shipping capability.

It is ugly in ways that feel familiar:

```text
STATUS_CD
ACCOUNT_NO
SHIP_REF
LAST_ERR
```

The temptation is:

> Rewrite it.

That is not yet an architecture.

## The Real Problem

The old implementation contains unknown knowledge.

Its clients depend on behavior we may not fully understand.

A replacement must coexist with the current system while confidence grows.

## The First Move

Put a routing boundary in front of the capability.

At first:

```text
100% -> Legacy
```

Nothing changes behaviorally.

But now there is an interception point.

That is the seed of Strangler Fig.

## Next

Move one narrow capability:

```text
shipping status
```

to the new Fulfillment module.

Keep the rest legacy.

That makes the migration reversible.
