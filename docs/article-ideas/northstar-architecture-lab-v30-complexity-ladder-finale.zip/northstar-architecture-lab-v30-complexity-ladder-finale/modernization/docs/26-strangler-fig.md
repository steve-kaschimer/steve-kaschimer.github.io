---
title: "Lab 26: Strangler Fig Moves One Capability at a Time"
series: "Modern Application Architecture Patterns in .NET"
volume: 2
category: "Architecture Lab"
lab_stage: "v27-strangler-fig"
status: "draft"
---

# Lab 26: Strangler Fig Moves One Capability at a Time

v26 gave us a routing point.

v27 uses it.

## The Route

The client still calls:

```text
GET /shipping/{orderId}
```

But the router can choose:

```text
Legacy Shipping
or
New Fulfillment
```

without changing the client contract.

## Anti-Corruption Layer

When traffic goes to Legacy, the application does **not** return:

```text
STATUS_CD = 4
SHIP_REF
```

directly.

The ACL translates it into Northstar's language:

```text
FulfillmentStatus.Shipped
ShipmentReference
```

That matters because migration should improve the model rather than copy legacy semantics into new code.

## Progressive Migration

Start with:

```text
UseNewFulfillment = false
```

Then enable the new path in a controlled environment.

The same routing concept can later become:

```text
specific tenant
specific customer cohort
specific endpoint
percentage rollout
```

## Rollback

If the new implementation misbehaves:

```text
route back to Legacy
```

That is the safety advantage.

The migration is reversible while data semantics still permit it.

## Retirement Is Part of the Pattern

A Strangler project is not complete when the new system exists.

It is complete when:

```text
old route removed
legacy implementation retired
temporary translation removed
```

Otherwise Northstar ends up operating both forever.

## The Lesson

Strangler Fig is not a rewrite technique.

It is a risk-management strategy for replacing behavior incrementally behind a stable boundary.
