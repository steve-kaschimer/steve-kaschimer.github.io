namespace Northstar.LegacyShipping;

public sealed class LegacyShippingService
{
    public LegacyShippingResponse GetByOrder(Guid orderId)
    {
        // Deliberately legacy-shaped response.
        return new LegacyShippingResponse(
            ACCOUNT_NO: $"A-{orderId.ToString()[..8]}",
            SHIP_REF: $"SHP-{orderId.ToString()[..6]}",
            STATUS_CD: 4,
            LAST_ERR: null);
    }
}

public sealed record LegacyShippingResponse(
    string ACCOUNT_NO,
    string SHIP_REF,
    int STATUS_CD,
    string? LAST_ERR);
