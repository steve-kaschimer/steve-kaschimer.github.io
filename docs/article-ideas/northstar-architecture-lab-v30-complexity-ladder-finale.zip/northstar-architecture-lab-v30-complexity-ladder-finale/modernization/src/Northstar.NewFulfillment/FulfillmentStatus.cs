namespace Northstar.NewFulfillment;

public enum FulfillmentStatus
{
    Pending = 0,
    Packed = 1,
    Shipped = 2,
    Delivered = 3
}

public sealed record FulfillmentSummary(
    Guid OrderId,
    string ShipmentReference,
    FulfillmentStatus Status);
