using Northstar.LegacyShipping;
using Northstar.Modernization.Host;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<LegacyShippingService>();
builder.Services.AddSingleton<FulfillmentModule>();
builder.Services.AddSingleton<ShippingAcl>();
builder.Services.AddSingleton<ShippingRouter>();

var app = builder.Build();

app.MapGet(
    "/shipping/{orderId:guid}",
    (
        Guid orderId,
        ShippingRouter router) =>
        Results.Ok(
            router.GetStatus(orderId)));

app.Run();
