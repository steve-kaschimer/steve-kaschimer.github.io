using Northstar.NewFulfillment;

namespace Northstar.Modernization.Host;

public sealed class FulfillmentModule
{
    public FulfillmentSummary GetStatus(Guid orderId)
        => new(
            orderId,
            $"NEW-{orderId.ToString()[..6]}",
            FulfillmentStatus.Shipped);
}
