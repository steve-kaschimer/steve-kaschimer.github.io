using Northstar.LegacyShipping;
using Northstar.NewFulfillment;

namespace Northstar.Modernization.Host;

public sealed class ShippingAcl
{
    public FulfillmentSummary Translate(
        Guid orderId,
        LegacyShippingResponse legacy)
    {
        var status =
            legacy.STATUS_CD switch
            {
                1 => FulfillmentStatus.Pending,
                2 => FulfillmentStatus.Packed,
                4 => FulfillmentStatus.Shipped,
                9 => FulfillmentStatus.Delivered,
                _ => throw new InvalidOperationException(
                    $"Unknown legacy shipping status {legacy.STATUS_CD}.")
            };

        return new FulfillmentSummary(
            orderId,
            legacy.SHIP_REF,
            status);
    }
}
