using Northstar.LegacyShipping;
using Northstar.NewFulfillment;

namespace Northstar.Modernization.Host;

public sealed class ShippingRouter(
    LegacyShippingService legacy,
    FulfillmentModule modern,
    ShippingAcl acl,
    IConfiguration configuration)
{
    public FulfillmentSummary GetStatus(Guid orderId)
    {
        var useModern =
            configuration.GetValue<bool>(
                "Modernization:UseNewFulfillment");

        if (useModern)
            return modern.GetStatus(orderId);

        var legacyResponse =
            legacy.GetByOrder(orderId);

        return acl.Translate(
            orderId,
            legacyResponse);
    }
}
